# Agente da impressora — Bocas Murchas

A VPS não alcança a impressora. Ela mora na LAN de alguém, atrás de um roteador
doméstico, e nenhuma porta vai ser aberta pra internet por causa de uma Kobra.
Então quem liga é um **Raspberry Pi ao lado da máquina**: ele conecta na API, a
conexão fica aberta, e por ela passam as peças e os reports.

Este repositório é esse processo.

```
   launcher            VPS                        casa do dono da impressora
  ┌────────┐      ┌──────────────┐               ┌──────────┐     ┌──────────┐
  │ fatia  │─────▶│ fila + cota  │◀── socket ────│ Pi Zero  │────▶│ Kobra S1 │
  │ e sobe │      │ (quem manda) │   (o Pi liga) │ (ponte)  │ MQTT│          │
  └────────┘      └──────────────┘               └──────────┘  +  └──────────┘
                                                              HTTP
```

**O agente não decide nada.** De quem é a vez, quanto foi cobrado, quando a mesa
está suja — tudo isso é do servidor. O Pi lê a máquina, conta o que viu e faz o
que mandam. É por isso que dá pra jogar o cartão SD fora e recomeçar sem
ninguém perder uma hora de cota.

## Roda num Pi Zero W?

Roda. O trabalho é de entrada e saída, não de CPU: manter um socket, baixar um
arquivo, empurrar pra impressora, repassar números. Três detalhes é que fazem
ele caber num aparelho de 512 MB e ARMv6:

- **Python, não Node.** O Node oficial não publica binário ARMv6 há anos. As
  três dependências aqui são wheel pura: instalam em segundos, sem compilar.
- **Nada em memória.** Download e upload são em stream, do disco pro disco. O
  multipart do upload é montado à mão (`transfer.py`) porque o `requests` monta
  o corpo inteiro na RAM — 80 MB de G-code num Pi Zero é o OOM killer no meio
  do envio.
- **Wifi sem power save.** O `install.sh` desliga. O socket fica horas ocioso
  durante uma impressão, que é exatamente o que o modo de economia derruba.

Num Pi Zero 2 W roda igual e sobra folga.

## Preparando o cartão (a primeira vez)

O Pi precisa estar **na rede** antes de qualquer coisa: ele não tem porta
ethernet, e o console serial por USB não é caminho — o gadget do Raspberry Pi OS
enumera no Windows e falha ao abrir (`ERROR_GEN_FAILURE 0x8007001F`), então não
conte com ele pra configurar nada.

Grave o cartão com o **Raspberry Pi Imager**, e use a engrenagem de
configuração ANTES de gravar:

- sistema: **Raspberry Pi OS Lite (32-bit)** — no Zero W tem que ser 32 bits,
  ele é ARMv6;
- hostname: `bocas-pi` (ou o que quiser — é por ele que o deploy acha a máquina);
- **SSH ligado**, com usuário e senha que você escolher;
- **wifi: o da casa ONDE A IMPRESSORA MORA**, não o seu. O Pi vai viver ao lado
  dela, e o wifi configurado aqui é o que ele vai procurar quando ligar lá. Se
  for gravar longe, dá pra acrescentar a outra rede depois, já dentro do Pi;
- país do wifi: `BR` (sem isso o rádio nem liga).

Põe o cartão no Pi, liga, espera um minuto e confirma que ele apareceu:

```powershell
ping bocas-pi.local
```

Se não responder, procure o IP na lista de clientes do roteador — o MAC de
Raspberry começa com `B8:27:EB`, `DC:A6:32` ou `E4:5F:01`.

## Instalar

No Pi (Raspberry Pi OS Lite, 32 bits no Zero W):

```bash
sudo ./install.sh
```

Do Windows, sem entrar no Pi na mão:

```powershell
.\deploy.ps1 -PiHost raspberrypi.local
```

Depois, o token:

1. no launcher, **Admin › Impressora › Agentes › Criar token**;
2. ele aparece **uma vez** — o servidor guarda só o hash;
3. cola em `/etc/bocas-agent/agent.conf`;
4. `sudo systemctl restart bocas-agent`.

O IP e a chave da impressora **não** ficam no Pi: moram no banco, em
**Admin › Impressora**, e chegam ao agente a cada conexão. Roteador reiniciou e
o IP mudou? Troca no launcher; ninguém abre SSH.

## Conferir

```bash
journalctl -u bocas-agent -f
```

O que se espera ver ao ligar:

```
bocas-agent 1.0.0 — API em https://api.bocasmurchas.com.br
conectado na API
impressora: Kobra S1 do grupo (Anycubic Kobra S1) em 192.168.0.50
assinado anycubic/anycubicCloud/v1/printer/#
descobri o deviceId da impressora: 1a2b3c...
```

Na aba Impressora do launcher, o agente aparece como **online** em segundos.

## A parte que precisa da máquina na frente

Tudo acima é código nosso, testado de ponta a ponta contra a API de verdade. O
que **não** dá pra garantir sem a impressora ligada é o dialeto do MQTT local da
Anycubic: ele não é documentado por ninguém, e o que se sabe veio de engenharia
reversa da comunidade.

Por isso o `printer.py` é tolerante (varre o JSON atrás das chaves conhecidas em
vez de exigir um formato), e por isso existe a sonda:

```bash
cd /opt/bocas-agent
sudo -u bocas venv/bin/python tools/probe.py --host 192.168.0.50
```

Ela não escreve nada na máquina. Em dois minutos mostra: o `deviceId` real, os
tópicos, como a impressora chama cada fase, e em que chave vêm `progress`,
`curr_layer`, `remain_time` e `supplies_usage`. Se algo não bater com o que
está em `bm_agent/printer.py`, o conserto é **acrescentar a chave nas listas do
topo daquele arquivo** — não reescrever nada.

Se o MQTT não conectar de jeito nenhum, tente na ordem: `--no-tls`,
`--mqtt-port 1883`, e conferir se a impressora está em modo LAN no painel dela.
Enquanto isso, o caminho HTTP (upload e start) já funciona sozinho — o que falta
sem MQTT é a telemetria fina e o pause/stop, e o agente cai pro `/api/job` da
camada OctoPrint pros comandos.

## Os arquivos

| arquivo | o que é |
| --- | --- |
| `bm_agent/hub.py` | o agente: socket com a API, fila de trabalho, heartbeat |
| `bm_agent/printer.py` | MQTT da Anycubic — o único pedaço escrito contra protocolo não documentado |
| `bm_agent/transfer.py` | baixar o G-code e empurrar pra impressora, tudo em stream |
| `bm_agent/config.py` | o `agent.conf` (só API e token; o resto vem do servidor) |
| `bm_agent/discovery.py` | acha a impressora na LAN por broadcast |
| `tools/probe.py` | a sonda do protocolo |
| `install.sh` | instalação e atualização no Pi |
| `deploy.ps1` | o mesmo, disparado do Windows |

## Protocolo com a API

Socket.IO, namespace `/print-agent`, token opaco no handshake.

**O agente manda:** `agent:hello`, `agent:heartbeat`, `agent:printer` (fase),
`agent:telemetry` (números), `agent:job-stage` (progresso da transferência),
`agent:job-accepted`, `agent:job-failed`.

**O servidor manda:** `agent:welcome` (configuração da impressora),
`job:print` (peça + URL assinada), `job:command` (pause/resume/stop),
`printer:sync`.

O `agent:job-stage` existe por causa do Pi: o prazo de confirmação do servidor é
de 60 s e um upload honesto de 80 MB passa disso. O evento remarca o relógio, e
o prazo volta a medir o que sempre quis medir — silêncio.
