<#
.SYNOPSIS
  Manda o agente pro Raspberry e instala. Roda no Windows.

.DESCRIPTION
  Copia o código por scp e executa o install.sh por ssh. É idempotente: rodar
  de novo publica versão nova sem perder a configuração do aparelho.

.EXAMPLE
  .\deploy.ps1 -PiHost raspberrypi.local
  .\deploy.ps1 -PiHost 192.168.0.42 -PiUser samu -Porta 22

.NOTES
  Precisa de ssh/scp no PATH (o Windows 11 já vem com os dois) e de acesso ao
  Pi por chave ou senha.
#>
param(
  [Parameter(Mandatory = $true)][string]$PiHost,
  [string]$PiUser = "pi",
  [int]$Porta = 22
)

$ErrorActionPreference = "Stop"
$raiz = $PSScriptRoot
$alvo = "$PiUser@$PiHost"
$remoto = "/tmp/bocas-agent-deploy"

Write-Host "==> conferindo o Pi em $alvo`:$Porta" -ForegroundColor Cyan
# Falhar AQUI é melhor que falhar no meio de um scp de dezenas de arquivos.
& ssh -p $Porta -o ConnectTimeout=8 -o StrictHostKeyChecking=accept-new $alvo "uname -a; python3 --version"
if ($LASTEXITCODE -ne 0) {
  throw "não consegui entrar no Pi. Confira o IP/nome, o usuário e se o SSH está ligado."
}

Write-Host "==> copiando o código" -ForegroundColor Cyan
& ssh -p $Porta $alvo "rm -rf $remoto && mkdir -p $remoto"
if ($LASTEXITCODE -ne 0) { throw "não deu pra preparar $remoto no Pi" }

# Só o que o instalador precisa. O `.git`, o venv local e o __pycache__ ficam.
$itens = @("bm_agent", "tools", "install.sh", "requirements.txt", "agent.conf.example", "bocas-agent.service")
foreach ($item in $itens) {
  $caminho = Join-Path $raiz $item
  if (-not (Test-Path $caminho)) { throw "faltando: $item" }
  & scp -P $Porta -r -q $caminho "$alvo`:$remoto/"
  if ($LASTEXITCODE -ne 0) { throw "falhou copiando $item" }
}

Write-Host "==> instalando (vai pedir a senha do sudo)" -ForegroundColor Cyan
& ssh -p $Porta -t $alvo "cd $remoto && chmod +x install.sh && sudo ./install.sh"
if ($LASTEXITCODE -ne 0) { throw "a instalação no Pi falhou — leia a saída acima" }

Write-Host ""
Write-Host "Pronto." -ForegroundColor Green
Write-Host "Token:   launcher › Admin › Impressora › Agentes › Criar token"
Write-Host "Colar:   sudo nano /etc/bocas-agent/agent.conf"
Write-Host "Ligar:   sudo systemctl restart bocas-agent"
Write-Host "Olhar:   ssh -p $Porta $alvo 'journalctl -u bocas-agent -f'"
