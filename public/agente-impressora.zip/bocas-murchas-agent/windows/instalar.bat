@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

echo.
echo == Bocas Murchas - agente da impressora (instalacao) ==
echo.

set "PY="
where py >nul 2>nul
if not errorlevel 1 set "PY=py -3"
if not defined PY (
  where python >nul 2>nul
  if not errorlevel 1 set "PY=python"
)
if not defined PY goto :sempython

echo Criando o ambiente...
%PY% -m venv venv
if errorlevel 1 goto :erro

echo Instalando as tres dependencias...
venv\Scripts\python.exe -m pip install --quiet --upgrade pip
venv\Scripts\python.exe -m pip install --quiet -r "%~dp0..\requirements.txt"
if errorlevel 1 goto :erro

if not exist "%~dp0agent.conf" (
  echo Criando o agent.conf a partir do exemplo...
  copy /y "%~dp0agent.conf.example" "%~dp0agent.conf" >nul
)

echo.
echo Pronto. Agora, nesta ordem:
echo.
echo   1) sonda.bat 192.168.x.x  - le a impressora por 2 min, nao escreve nada nela
echo   2) no launcher: Admin ^> Impressora ^> Agentes ^> Criar token
echo   3) cole o bloco por cima do agent.conf INTEIRO, salve, e rode agente.bat
echo.
echo Vou abrir o agent.conf pra voce.
start "" notepad "%~dp0agent.conf"
pause
exit /b 0

:sempython
echo Python nao encontrado.
echo Instale o Python 3 em https://www.python.org/downloads/
echo IMPORTANTE: marque "Add python.exe to PATH" na PRIMEIRA tela do instalador.
pause
exit /b 1

:erro
echo.
echo Falhou. Tira um print desta janela inteira e manda pro Paulo.
pause
exit /b 1
