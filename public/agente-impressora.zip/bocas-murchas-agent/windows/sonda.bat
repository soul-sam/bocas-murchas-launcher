@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set "PYTHONIOENCODING=utf-8"

if not exist venv\Scripts\python.exe (
  echo Rode o instalar.bat primeiro.
  pause
  exit /b 1
)

echo.
echo == Sonda: so LE a impressora. Nao manda imprimir, nao move nada. ==
echo Deixe rodar os 2 minutos e me mande o arquivo sonda.jsonl que aparecer aqui.
echo.

if "%~1"=="" (
  echo Sem IP: vou procurar a impressora na rede.
  venv\Scripts\python.exe "%~dp0..\tools\probe.py" --out "%~dp0sonda.jsonl"
) else (
  venv\Scripts\python.exe "%~dp0..\tools\probe.py" --host %1 --out "%~dp0sonda.jsonl"
)

echo.
pause
