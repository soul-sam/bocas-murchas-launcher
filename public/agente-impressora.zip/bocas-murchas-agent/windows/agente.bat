@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0.."
set "PYTHONIOENCODING=utf-8"

if not exist "%~dp0venv\Scripts\python.exe" (
  echo Rode o instalar.bat primeiro.
  pause
  exit /b 1
)

echo.
echo == Agente da impressora. Deixe esta janela aberta. ==
echo Fechar a janela e o mesmo que desligar a impressora pro grupo.
echo.

:loop
"%~dp0venv\Scripts\python.exe" -m bm_agent -c "%~dp0agent.conf"
echo.
echo O agente parou. Subo de novo em 10 segundos - feche a janela pra parar de vez.
timeout /t 10 >nul
goto loop
