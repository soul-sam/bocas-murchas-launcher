"""
Log do agente.

Vai pro stdout e o `systemd` recolhe no journal — sem arquivo próprio, sem
rotação pra configurar, e principalmente sem escrita constante no cartão SD,
que é o que mata Raspberry ligado o ano inteiro.
"""
from __future__ import annotations

import logging
import sys

_CONFIGURED = False


def setup(level: str = "INFO") -> None:
    global _CONFIGURED
    if _CONFIGURED:
        return

    # Força UTF-8 na saída.
    #
    # Sem isto, um Pi com `LANG` vazio (que é o padrão de uma instalação Lite
    # enxuta) deixa o stdout em ASCII, e a primeira mensagem com acento ou seta
    # derruba o agente inteiro com `UnicodeEncodeError` — no meio de uma
    # impressão, e por causa de um log.
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
    except (AttributeError, ValueError):
        pass

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)-7s %(name)-12s %(message)s"))

    root = logging.getLogger()
    root.handlers.clear()
    root.addHandler(handler)
    root.setLevel(getattr(logging, level.upper(), logging.INFO))

    # O socketio/engineio em DEBUG despeja cada pacote de ping. Útil uma vez na
    # vida, ruído em todas as outras.
    logging.getLogger("socketio.client").setLevel(logging.WARNING)
    logging.getLogger("engineio.client").setLevel(logging.WARNING)
    logging.getLogger("urllib3").setLevel(logging.WARNING)

    _CONFIGURED = True


def get(name: str) -> logging.Logger:
    return logging.getLogger(name)
