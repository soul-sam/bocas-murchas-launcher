"""
Agente da impressora 3D do Bocas Murchas.

A VPS não alcança a impressora — ela mora na LAN de alguém, atrás de um
roteador doméstico. Este processo roda num Raspberry Pi ao lado da máquina e é
a ponte: recebe a peça da API, entrega pra impressora e conta de volta o que
está acontecendo.

Ele não decide nada sobre a fila. Isso é do servidor, e é o que permite jogar o
cartão SD fora e recomeçar sem perder uma hora de cota de ninguém.

Nada é importado aqui de propósito: a sonda (`tools/probe.py`) precisa mexer só
com MQTT, e importar o pacote não pode exigir o `python-socketio` instalado.
"""

VERSION = "1.0.0"

__all__ = ["VERSION"]
