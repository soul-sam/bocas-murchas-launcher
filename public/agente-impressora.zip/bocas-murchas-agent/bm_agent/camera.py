"""
A CÂMERA — snapshot JPEG da impressora, só enquanto alguém está olhando.

A VPS não alcança a câmera (ela mora na LAN, igual à impressora), então quem
leva a imagem é o agente, pelo mesmo socket da ponte. Duas regras de projeto:

1. **Sob demanda.** Cada quadro de 720p tem ~240 KB. Mandando o dia inteiro,
   seria a franquia do roteador de alguém indo embora pra ninguém ver. O
   servidor manda `camera:start` quando alguém abre a tela e `camera:stop`
   quando o último sai.

2. **Morre sozinha.** O `camera:start` tem validade (`ttl`): o servidor renova
   enquanto houver gente olhando. Se a API cair, reiniciar ou esquecer de
   mandar o `stop`, o envio para em segundos em vez de ficar subindo imagem pra
   um socket que ninguém lê.

Snapshot e não o stream MJPEG: um GET por quadro é trivial de ritmar, e o
mjpg-streamer do Rinkhals serve `?action=snapshot` sem custo extra.
"""
from __future__ import annotations

import threading
import time
from typing import Callable

import requests

from . import log

LOG = log.get("camera")

MAX_FPS = 5.0
MIN_FPS = 0.2
DEFAULT_TTL = 30.0
FETCH_TIMEOUT = 5


class CameraRelay:
    def __init__(self, url_for: Callable[[], str | None], send: Callable[[bytes], bool]) -> None:
        self._url_for = url_for
        self._send = send
        self._lock = threading.Lock()
        self._wake = threading.Event()
        self._thread: threading.Thread | None = None
        self._until = 0.0
        self._interval = 1.0
        self._failures = 0

    def start(self, fps: float | None = None, ttl: float | None = None) -> None:
        """Liga (ou renova) o envio por `ttl` segundos."""
        rate = max(MIN_FPS, min(MAX_FPS, float(fps or 1.0)))
        with self._lock:
            first = time.time() >= self._until
            self._interval = 1.0 / rate
            self._until = time.time() + max(5.0, float(ttl or DEFAULT_TTL))
            if self._thread is None or not self._thread.is_alive():
                self._thread = threading.Thread(target=self._loop, name="camera", daemon=True)
                self._thread.start()
        if first:
            LOG.info("câmera ligada (%.1f fps)", rate)
        self._wake.set()

    def stop(self) -> None:
        with self._lock:
            was_on = time.time() < self._until
            self._until = 0.0
        if was_on:
            LOG.info("câmera desligada")
        self._wake.set()

    def _loop(self) -> None:
        while True:
            with self._lock:
                until, interval = self._until, self._interval
            if time.time() >= until:
                # Parado: dorme até alguém pedir de novo.
                self._wake.wait()
                self._wake.clear()
                continue

            began = time.time()
            frame = self._grab()
            if frame:
                self._send(frame)

            # Câmera fora do ar (mjpg-streamer reiniciando): não martelar.
            pause = interval if self._failures == 0 else min(10.0, interval * (1 + self._failures))
            self._wake.wait(max(0.0, pause - (time.time() - began)))
            self._wake.clear()

    def _grab(self) -> bytes | None:
        url = self._url_for()
        if not url:
            return None
        try:
            response = requests.get(url, timeout=FETCH_TIMEOUT)
            response.raise_for_status()
            body = response.content
            # JPEG começa com FF D8. Qualquer outra coisa é página de erro.
            if not body.startswith(b"\xff\xd8"):
                raise ValueError(f"não é JPEG ({response.headers.get('content-type')})")
            if self._failures:
                LOG.info("câmera voltou")
            self._failures = 0
            return body
        except Exception as error:  # noqa: BLE001
            self._failures += 1
            if self._failures in (1, 10) or self._failures % 60 == 0:
                LOG.warning("sem imagem da câmera em %s: %s", url, error)
            return None
