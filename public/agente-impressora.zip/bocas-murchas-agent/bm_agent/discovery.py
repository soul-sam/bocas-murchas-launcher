"""
Achar a impressora na LAN.

Existe pra responder uma pergunta chata na instalação: "qual é o IP da
impressora?". A resposta certa é "olha no painel dela", mas quem está instalando
o Pi costuma estar num cômodo diferente — então o agente também sabe procurar.

A Anycubic responde a um broadcast UDP na porta 6000 com um JSON de
identificação. Isto NÃO é caminho crítico: se não achar, o IP configurado no
servidor continua valendo. É conveniência de instalação, não dependência.
"""
from __future__ import annotations

import json
import socket
import time
from typing import Any

from . import log

LOG = log.get("discovery")

DISCOVERY_PORT = 6000
PROBE = b"M99999"


def find_printers(timeout: float = 3.0) -> list[dict[str, Any]]:
    """
    Manda um broadcast e junta quem responder.

    Devolve lista de dicionários com pelo menos `ip`; o resto é o que a máquina
    quiser contar (nome, modelo, id da placa).
    """
    found: dict[str, dict[str, Any]] = {}

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    sock.settimeout(0.5)

    try:
        sock.sendto(PROBE, ("255.255.255.255", DISCOVERY_PORT))
    except OSError as error:
        LOG.debug("broadcast não saiu: %s", error)
        sock.close()
        return []

    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            data, addr = sock.recvfrom(4096)
        except socket.timeout:
            continue
        except OSError:
            break

        ip = addr[0]
        info: dict[str, Any] = {"ip": ip, "raw": data[:400].decode("utf-8", errors="replace")}
        try:
            parsed = json.loads(data.decode("utf-8", errors="replace"))
            if isinstance(parsed, dict):
                info.update({str(k): v for k, v in parsed.items()})
        except ValueError:
            # Algumas respondem texto solto no lugar de JSON. O IP já resolve o
            # problema de quem está instalando.
            pass

        found[ip] = info

    sock.close()
    return list(found.values())
