"""
A CONVERSA COM A MÁQUINA — MQTT local da Anycubic.

Um aviso honesto pra quem mexer aqui depois: este é o único arquivo do projeto
inteiro escrito contra um protocolo que ninguém documentou. A Kobra fala um
MQTT próprio na LAN, e o que se sabe dele veio de engenharia reversa da
comunidade. Duas consequências de projeto:

1. **Nada aqui exige formato.** O parser não procura `data.progress` num
   caminho fixo: ele varre o JSON recursivamente atrás de chaves conhecidas
   (`progress`, `curr_layer`, `remain_time`…). Se a Anycubic aninhar mais um
   nível numa atualização de firmware, o agente continua funcionando em vez de
   cair calado — que é o modo de falhar que ninguém percebe até a peça sair
   errada.

2. **O que não é conhecido é reportado, não adivinhado.** Fase que o parser não
   reconhece sobe pro servidor VERBATIM, e o servidor, por sua vez, não mexe no
   estado do job quando não entende a fase. Melhor uma tela dizendo
   "flow_calibrating" do que um job marcado como terminado porque alguém supôs.

O `tools/probe.py` existe pra fechar essas lacunas com a máquina na frente: ele
conecta, despeja o JSON cru e diz exatamente o que precisa virar constante
aqui.
"""
from __future__ import annotations

import json
import ssl
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable

import paho.mqtt.client as mqtt

from . import log

LOG = log.get("printer")

# Fases que a máquina reporta, na grafia dela. `stoped` com um p só é a grafia
# REAL do firmware — não é erro de digitação, e corrigir aqui quebraria o
# reconhecimento.
KNOWN_PHASES = {
    "preheating",
    "auto_leveling",
    "vibrating",
    "flow_calibrating",
    "printing",
    "pausing",
    "paused",
    "resuming",
    "stopping",
    "stoped",
    "stopped",
    "finished",
    "failed",
    "idle",
    "free",
    "ready",
}

# Chaves procuradas no JSON, em qualquer profundidade.
PHASE_KEYS = ("state", "print_state", "printstate", "job_state", "status")
FILE_KEYS = ("filename", "file_name", "name", "print_name")
TASK_KEYS = ("taskid", "task_id")
CODE_KEYS = ("code", "err_code", "error_code")
# Códigos de sucesso do envelope do report (não são erro): 0 e 200 (estilo HTTP).
OK_CODES = frozenset({0, 200})
MESSAGE_KEYS = ("msg", "message", "err_msg")

# `state: "done"` é o ACK de um comando (luz, consulta), não fase da máquina. Lido
# como fase, faria o servidor achar que a impressora largou a peça.
NOT_PHASES = frozenset({"done"})
IDLE_PHASES = frozenset({"idle", "free", "ready"})
TERMINAL_PHASES = frozenset({"finished", "stoped", "stopped", "failed"})

# Campos da peça atual. Zerados quando a máquina diz que não tem peça, senão a
# próxima começa mostrando o 100% / "faltam 0" da anterior.
JOB_FIELDS = (
    "filename",
    "task_id",
    "progress",
    "curr_layer",
    "total_layers",
    "remain_minutes",
    "print_time_seconds",
    "supplies_usage",
)


@dataclass
class PrinterState:
    """O retrato mais recente da máquina, já normalizado."""

    phase: str | None = None
    filename: str | None = None
    task_id: str | None = None
    progress: float | None = None
    curr_layer: int | None = None
    total_layers: int | None = None
    remain_minutes: float | None = None
    print_time_seconds: float | None = None
    supplies_usage: float | None = None
    error_code: int | None = None
    error_message: str | None = None
    updated_at: float = field(default_factory=time.time)

    def as_report(self) -> dict[str, Any]:
        """O que o servidor espera em `agent:printer`."""
        return {
            "phase": self.phase,
            "filename": self.filename,
            "taskId": self.task_id,
            "errorCode": self.error_code,
            "errorMessage": self.error_message,
        }

    def as_telemetry(self) -> dict[str, Any]:
        """O que o servidor espera em `agent:telemetry`."""
        return {
            "progress": self.progress,
            "currLayer": self.curr_layer,
            "totalLayers": self.total_layers,
            "remainMinutes": self.remain_minutes,
            "printTimeSeconds": self.print_time_seconds,
            "suppliesUsage": self.supplies_usage,
        }

    def busy(self) -> bool:
        return self.phase is not None and self.phase not in {"idle", "free", "ready"}


def _new_client(client_id: str) -> mqtt.Client:
    """
    Cria o client funcionando tanto no paho 1.6 quanto no 2.x.

    O 2.0 mudou a assinatura dos callbacks e exige declarar a versão da API. O
    Pi pode ter qualquer um dos dois dependendo de quando o venv foi criado, e
    descobrir isso por exceção de `TypeError` em produção é péssimo.
    """
    try:
        return mqtt.Client(
            mqtt.CallbackAPIVersion.VERSION1,  # type: ignore[attr-defined]
            client_id=client_id,
            protocol=mqtt.MQTTv311,
        )
    except AttributeError:
        return mqtt.Client(client_id=client_id, protocol=mqtt.MQTTv311)


class PrinterLink:
    """
    Conexão com a impressora. Reconecta sozinha, pra sempre.

    A impressora some quando alguém desliga na tomada ou o roteador reinicia —
    isso é rotina, não exceção, e por isso não existe caminho de erro que
    encerre o processo. O agente fica tentando e avisa o servidor que a máquina
    está inalcançável; a fila espera, que é o comportamento certo.
    """

    def __init__(
        self,
        on_state: Callable[[PrinterState], None],
        on_raw: Callable[[str, dict[str, Any]], None] | None = None,
        on_light: Callable[[bool], None] | None = None,
        on_ace: Callable[[dict[str, Any]], None] | None = None,
    ) -> None:
        self.state = PrinterState()
        # ACE (caixa de 4 filamentos). Repassado ao servidor já normalizado;
        # quem decide se a peça bate com o que está carregado é a API.
        self._on_ace = on_ace
        self.connected = False
        # Luz da câmara. `None` = ainda não perguntei.
        self.light_on: bool | None = None
        self._on_light = on_light
        self.host: str | None = None
        self.model_id: int = 20025
        self.device_id: str | None = None
        self.topic_root = "anycubic/anycubicCloud/v1"

        self._on_state = on_state
        self._on_raw = on_raw
        self._client: mqtt.Client | None = None
        self._lock = threading.Lock()
        self._tls: dict[str, Any] = {}
        self._auth: tuple[str | None, str | None] = (None, None)
        self._port = 9883

    # ------------------------------------------------------------------
    # LIGAÇÃO
    # ------------------------------------------------------------------

    def configure(
        self,
        host: str,
        *,
        model_id: int,
        device_id: str | None,
        port: int,
        topic_root: str,
        tls: bool,
        tls_insecure: bool,
        ca_file: str | None,
        certfile: str | None,
        keyfile: str | None,
        username: str | None,
        password: str | None,
    ) -> None:
        """
        (Re)configura e conecta. Chamado a cada `agent:welcome`.

        Se só o IP mudou, derruba e sobe de novo — é barato e não tem estado a
        preservar: o primeiro report da máquina reconstrói tudo.
        """
        with self._lock:
            same = (
                self.host == host
                and self.model_id == model_id
                and self._port == port
                and self.device_id == device_id
            )
            if same and self.connected:
                return

            self.host = host
            self.model_id = model_id
            self.device_id = device_id
            self.topic_root = topic_root.strip("/")
            self._port = port
            self._tls = {
                "enabled": tls,
                "insecure": tls_insecure,
                "ca_file": ca_file,
                "certfile": certfile,
                "keyfile": keyfile,
            }
            self._auth = (username, password)

        self._reconnect()

    def _reconnect(self) -> None:
        self.stop()
        if not self.host:
            return

        client = _new_client(f"bocas-agent-{uuid.uuid4().hex[:8]}")
        username, password = self._auth
        if username:
            client.username_pw_set(username, password or None)

        if self._tls.get("enabled"):
            try:
                client.tls_set(
                    ca_certs=self._tls.get("ca_file"),
                    certfile=self._tls.get("certfile"),
                    keyfile=self._tls.get("keyfile"),
                    cert_reqs=ssl.CERT_NONE if self._tls.get("insecure") else ssl.CERT_REQUIRED,
                    tls_version=ssl.PROTOCOL_TLS_CLIENT,
                )
                if self._tls.get("insecure"):
                    # O certificado é da própria impressora e nenhuma CA
                    # assinou. Estamos na mesma LAN que ela; a alternativa é não
                    # ter canal nenhum.
                    client.tls_insecure_set(True)
            except Exception as error:  # noqa: BLE001
                LOG.error("TLS não configurou (%s) — tentando sem", error)

        client.on_connect = self._on_connect
        client.on_message = self._on_message
        client.on_disconnect = self._on_disconnect
        # `reconnect_delay_set` + `loop_start` fazem a reconexão sozinhos: sem
        # isso, uma queda do roteador deixaria o agente mudo pra sempre.
        client.reconnect_delay_set(min_delay=2, max_delay=60)

        self._client = client
        LOG.info("conectando na impressora %s:%s", self.host, self._port)
        try:
            client.connect_async(self.host, self._port, keepalive=45)
            client.loop_start()
        except Exception as error:  # noqa: BLE001
            LOG.error("falha ao conectar em %s:%s — %s", self.host, self._port, error)

    def stop(self) -> None:
        client, self._client = self._client, None
        self.connected = False
        if not client:
            return
        try:
            client.loop_stop()
            client.disconnect()
        except Exception:  # noqa: BLE001
            pass

    # ------------------------------------------------------------------
    # CALLBACKS
    # ------------------------------------------------------------------

    def _on_connect(self, client: mqtt.Client, _userdata: Any, _flags: Any, rc: int, *_rest) -> None:
        if rc != 0:
            LOG.error("impressora recusou a conexão (rc=%s)", rc)
            return

        self.connected = True

        # Curinga de propósito: o `deviceId` (mainboard) muitas vezes não é
        # conhecido de antemão, e é justamente o que aparece no TÓPICO do
        # primeiro report. Assinar tudo e aprender o id do tópico evita ter que
        # configurar na mão um número que ninguém sabe onde achar.
        topic = f"{self.topic_root}/printer/#"
        client.subscribe(topic, qos=0)
        LOG.info("assinado %s", topic)

        self.request_status()
        self.request_light()
        self.request_ace()

    def _on_disconnect(self, _client: mqtt.Client, _userdata: Any, rc: int, *_rest) -> None:
        self.connected = False
        LOG.warning("impressora desconectou (rc=%s) — o paho reconecta sozinho", rc)

    def _on_message(self, _client: mqtt.Client, _userdata: Any, message: mqtt.MQTTMessage) -> None:
        try:
            raw = message.payload.decode("utf-8", errors="replace")
            payload = json.loads(raw)
        except (ValueError, AttributeError):
            LOG.debug("payload não-JSON em %s", message.topic)
            return

        if not isinstance(payload, dict):
            return

        # O tópico é `.../printer/public/<modelId>/<deviceId>/<ação>/report`.
        parts = message.topic.split("/")
        if self.device_id is None and len(parts) >= 7:
            self.device_id = parts[6]
            LOG.info("descobri o deviceId da impressora: %s", self.device_id)

        if self._on_raw:
            try:
                self._on_raw(message.topic, payload)
            except Exception:  # noqa: BLE001
                LOG.exception("handler de payload cru falhou")

        # O report da luz não é estado da impressão: tem `state: "done"` e um
        # `status` numérico que o parser genérico leria como fase.
        action = parts[-2] if len(parts) >= 2 else ""
        if action == "light":
            self._take_light(payload)
            return
        # O report do ACE também tem `status` numérico por slot, que o parser
        # genérico leria como fase da impressão.
        if action == "multiColorBox":
            self._take_ace(payload)
            return

        if self._merge(payload, action):
            self._on_state(self.state)

    def _take_light(self, payload: dict[str, Any]) -> None:
        data = payload.get("data")
        if not isinstance(data, dict):
            return
        # A consulta responde `data.lights: [{type, status, brightness}]`; o
        # comando ecoa `data: {type, status, brightness}`.
        lights = data.get("lights")
        entry = lights[0] if isinstance(lights, list) and lights and isinstance(lights[0], dict) else data
        status = _as_int(entry.get("status"))
        if status is None:
            return
        on = status != 0
        if on != self.light_on:
            self.light_on = on
            LOG.info("luz %s", "acesa" if on else "apagada")
        if self._on_light:
            try:
                self._on_light(on)
            except Exception:  # noqa: BLE001
                LOG.exception("handler da luz falhou")

    def _take_ace(self, payload: dict[str, Any]) -> None:
        """
        `multiColorBox/report`: `data.multi_color_box` é uma lista de caixas
        (dois ACE encadeados = duas), cada uma com `loaded_slot` e `slots`
        `[{index, type, color: [r, g, b], status}]`. Formato conferido no bridge
        da comunidade pra S1 (metheos/anycubic-s1-mqtt-bridge).
        """
        data = payload.get("data")
        boxes = data.get("multi_color_box") if isinstance(data, dict) else None
        if not isinstance(boxes, list) or not boxes:
            return

        out: list[dict[str, Any]] = []
        for box in boxes:
            if not isinstance(box, dict):
                continue
            slots = []
            for position, slot in enumerate(box.get("slots") or []):
                if not isinstance(slot, dict):
                    continue
                color = slot.get("color")
                hex_color = None
                if isinstance(color, list) and len(color) >= 3 and all(isinstance(c, (int, float)) for c in color[:3]):
                    hex_color = "#" + "".join(f"{max(0, min(255, int(c))):02x}" for c in color[:3])
                kind = slot.get("type")
                slots.append(
                    {
                        "index": _as_int(slot.get("index")) if slot.get("index") is not None else position,
                        "type": kind.strip().upper() if isinstance(kind, str) and kind.strip() else None,
                        "colorHex": hex_color,
                        "status": _as_int(slot.get("status")),
                    }
                )
            out.append({"loadedSlot": _as_int(box.get("loaded_slot")), "slots": slots})

        if out and self._on_ace:
            try:
                self._on_ace({"boxes": out})
            except Exception:  # noqa: BLE001
                LOG.exception("handler do ACE falhou")

    # ------------------------------------------------------------------
    # PARSER TOLERANTE
    # ------------------------------------------------------------------

    def _merge(self, payload: dict[str, Any], action: str = "") -> bool:
        """
        Costura o report no retrato atual. Devolve se algo mudou.

        Merge e não substituição porque a máquina manda reports PARCIAIS: um
        pacote de temperatura não traz `progress`, e sobrescrever zeraria a
        barra da tela a cada dois segundos.
        """
        payload, idle = self._view(payload, action)
        flat = _flatten(payload)
        changed = False

        if idle:
            for attr in JOB_FIELDS:
                if getattr(self.state, attr) is not None:
                    setattr(self.state, attr, None)
                    changed = True

        phase = _first_phase(flat)
        # O `status/report` resume a máquina num genérico (`busy`); o `info` diz
        # a fase de verdade (`printing`, `auto_leveling`). O genérico não apaga
        # o específico, senão a tela piscaria entre os dois a cada heartbeat.
        working = self.state.busy() and self.state.phase not in TERMINAL_PHASES
        if phase and phase not in KNOWN_PHASES and self.state.phase in KNOWN_PHASES and working:
            phase = None
        # Peça terminando: o `free` do `status/report` chega antes do desfecho.
        # Aceitar ali faria o servidor ver "imprimindo" → "livre" e dar a peça
        # como perdida. Quem encerra é o `info`, que traz o `last_project`.
        if phase in IDLE_PHASES and working and action != "info":
            phase = None
            self.request_info()
        if phase and phase != self.state.phase:
            self.state.phase = phase
            changed = True

        for keys, attr, caster in (
            (FILE_KEYS, "filename", _as_filename),
            (TASK_KEYS, "task_id", _as_text),
            (("progress",), "progress", _as_float),
            (("curr_layer", "current_layer"), "curr_layer", _as_int),
            (("total_layers", "total_layer"), "total_layers", _as_int),
            (("remain_time", "remaining_time"), "remain_minutes", _as_float),
            (("print_time", "printed_time"), "print_time_seconds", _as_float),
            (("supplies_usage", "filament_used"), "supplies_usage", _as_float),
        ):
            value = _first(flat, keys, caster)
            if value is not None and getattr(self.state, attr) != value:
                setattr(self.state, attr, value)
                changed = True

        code = _first(flat, CODE_KEYS, _as_int)
        # `code: 0` E `code: 200` são "deu certo" — o report da S1 traz `code:200`
        # no envelope (estilo HTTP) em TODO relatório normal. Só código fora do
        # conjunto de sucesso vira erro na tela do grupo (erros reais são de 5
        # dígitos: 10101 ocupada, 10107 filamento rompido).
        if code and code not in OK_CODES:
            if self.state.error_code != code:
                self.state.error_code = code
                self.state.error_message = _first(flat, MESSAGE_KEYS, _as_text)
                changed = True
        elif code in OK_CODES and self.state.error_code is not None:
            self.state.error_code = None
            self.state.error_message = None
            changed = True

        if changed:
            self.state.updated_at = time.time()
        return changed

    def _view(self, payload: dict[str, Any], action: str) -> tuple[dict[str, Any], bool]:
        """
        O pedaço do report que fala da peça ATUAL. Devolve também se a máquina
        disse que não tem peça nenhuma.

        O `info/report` da S1 traz `project` (a peça de agora) E `last_project`
        (a anterior, com `progress: 100`, `remain_time: 0`, `state: finished`).
        Achatado inteiro, `last_project` vem depois e ganha — e a tela mostrava a
        peça recém-mandada como se já tivesse terminado. Então: do `info` só o
        `project` conta; de qualquer outro report, `last_project` é descartado.
        """
        data = payload.get("data")
        if action == "info" and isinstance(data, dict) and "project" in data:
            project = data.get("project")
            if isinstance(project, dict):
                return project, False

            # Sem peça. Se a que estava na máquina era a nossa e acabou de sair,
            # o desfecho dela (`finished`/`stoped`) só existe no `last_project`:
            # passa ele UMA vez, senão o servidor veria "imprimindo" → "livre"
            # sem nunca saber que terminou.
            last = data.get("last_project")
            if (
                isinstance(last, dict)
                and self.state.busy()
                and self.state.phase not in TERMINAL_PHASES
                and self.state.filename
                and _as_filename(last.get("filename")) == self.state.filename
            ):
                return last, False
            return {"state": data.get("state")}, True

        return _without(payload, "last_project"), False

    # ------------------------------------------------------------------
    # COMANDOS
    # ------------------------------------------------------------------

    def _publish(self, action: str, payload: dict[str, Any], kind: str = "web") -> bool:
        client = self._client
        if not client or not self.connected or not self.device_id:
            LOG.warning("sem canal com a impressora: comando %s não saiu", action)
            return False

        topic = f"{self.topic_root}/{kind}/printer/{self.model_id}/{self.device_id}/{action}"
        body = {
            "type": action,
            "timestamp": int(time.time() * 1000),
            "msgid": uuid.uuid4().hex,
            **payload,
        }
        LOG.info("→ %s %s", topic, json.dumps(body)[:200])
        result = client.publish(topic, json.dumps(body), qos=0)
        return result.rc == mqtt.MQTT_ERR_SUCCESS

    def request_status(self) -> bool:
        return self._publish("status", {"action": "query", "data": None})

    def request_info(self) -> bool:
        """
        Pergunta o snapshot completo (`info/report`), que é ONDE mora o progresso.

        Durante a impressão a S1 só EMPURRA `tempature/report` (temperatura); o
        bloco `project` (progress, curr_layer, remain_time, supplies_usage) só
        aparece no `info/report`, e só quando alguém pergunta. Sem esta query o
        servidor recebe telemetria sem progresso e a tela fica vazia. A pergunta
        vai no ramo `slicer/` (é o que a máquina responde com o snapshot cheio).
        """
        return self._publish("info", {"action": "query"}, kind="slicer")

    def start_print(self, filename: str) -> bool:
        """
        Manda imprimir um arquivo que JÁ ESTÁ na impressora.

        O upload é HTTP (ver `upload.py`); isto aqui só aperta o play. Separar
        os dois é o que permite subir o arquivo com o `print=true` do
        OctoPrint e usar este caminho só como plano B.
        """
        return self._publish(
            "print",
            {
                "action": "start",
                "data": {"taskid": "0", "filename": filename, "filetype": 1},
            },
        )

    def pause(self) -> bool:
        return self._publish("print", {"action": "pause", "data": {"taskid": self.state.task_id or "0"}})

    def resume(self) -> bool:
        return self._publish("print", {"action": "resume", "data": {"taskid": self.state.task_id or "0"}})

    def stop_print(self) -> bool:
        """Para a IMPRESSÃO. (`stop()` desliga o MQTT — nomes parecidos, vidas diferentes.)"""
        return self._publish("print", {"action": "stop", "data": {"taskid": self.state.task_id or "0"}})

    def request_light(self) -> bool:
        return self._publish("light", {"action": "query", "data": None})

    def request_ace(self) -> bool:
        """Pergunta o que está em cada slot do ACE. Só leitura."""
        return self._publish("multiColorBox", {"action": "getInfo", "data": None})

    def set_light(self, on: bool) -> bool:
        """Luz da câmara (`type: 2`). A máquina confirma no `light/report`."""
        return self._publish(
            "light",
            {
                "action": "control",
                "data": {"type": 2, "status": 1 if on else 0, "brightness": 100 if on else 0},
            },
        )


# ----------------------------------------------------------------------
# AJUDANTES DO PARSER
# ----------------------------------------------------------------------


def _flatten(payload: Any, depth: int = 0) -> dict[str, Any]:
    """
    Achata o JSON inteiro num dicionário `chave -> valor`.

    Chave repetida em profundidades diferentes fica com a MAIS FUNDA, que é
    onde a Anycubic costuma pôr o valor específico (`data.progress` vale mais
    que um `progress` de envelope). O limite de profundidade é só pra um
    payload malformado não virar recursão infinita.
    """
    out: dict[str, Any] = {}
    if depth > 6:
        return out

    if isinstance(payload, dict):
        for key, value in payload.items():
            if isinstance(value, (dict, list)):
                out.update(_flatten(value, depth + 1))
            else:
                out[str(key).lower()] = value
    elif isinstance(payload, list):
        for item in payload[:20]:
            out.update(_flatten(item, depth + 1))

    return out


def _without(payload: Any, drop: str) -> Any:
    """Cópia do JSON sem a chave `drop`, em qualquer profundidade."""
    if isinstance(payload, dict):
        return {k: _without(v, drop) for k, v in payload.items() if str(k).lower() != drop}
    if isinstance(payload, list):
        return [_without(item, drop) for item in payload]
    return payload


def _first(flat: dict[str, Any], keys: tuple[str, ...], caster) -> Any:
    for key in keys:
        if key in flat:
            value = caster(flat[key])
            if value is not None:
                return value
    return None


def _first_phase(flat: dict[str, Any]) -> str | None:
    """
    Acha a fase.

    Chave conhecida com valor conhecido ganha. Se nada bater, devolve o valor
    cru da primeira chave de fase — o servidor guarda verbatim e NÃO mexe no
    estado do job quando não entende, que é o comportamento seguro.
    """
    fallback: str | None = None
    for key in PHASE_KEYS:
        value = flat.get(key)
        if not isinstance(value, str):
            continue
        cleaned = value.strip().lower()
        if not cleaned or cleaned in NOT_PHASES:
            continue
        if cleaned in KNOWN_PHASES:
            return cleaned
        fallback = fallback or cleaned
    return fallback


def _as_text(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text[:200] or None


def _as_filename(value: Any) -> str | None:
    text = _as_text(value)
    if not text:
        return None
    # A máquina às vezes devolve caminho completo (`/useremain/x.gcode`).
    return text.rsplit("/", 1)[-1]


def _as_float(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if number == number else None  # NaN


def _as_int(value: Any) -> int | None:
    number = _as_float(value)
    return int(number) if number is not None else None
