"""
A CONVERSA COM A MÁQUINA — MQTT local da Anycubic.

Um aviso honesto pra quem mexer aqui depois: este é o único arquivo do projeto
inteiro escrito contra um protocolo que ninguém documentou. A Kobra fala um
MQTT próprio na LAN, e o que se sabe dele veio de engenharia reversa da
comunidade. Duas consequências de projeto:

1. **Nada aqui exige formato.** O parser não procura `data.progress` num
   caminho fixo: ele varre o JSON recursivamente atrás de chaves conhecidas
   (`progress`, `curr_layer`, `remain_time`…). Se a Anycubic aninhar mais um
   nível numa atualização de firmware, o agente continua funcionando em vez de
   cair calado — que é o modo de falhar que ninguém percebe até a peça sair
   errada.

2. **O que não é conhecido é reportado, não adivinhado.** Fase que o parser não
   reconhece sobe pro servidor VERBATIM, e o servidor, por sua vez, não mexe no
   estado do job quando não entende a fase. Melhor uma tela dizendo
   "flow_calibrating" do que um job marcado como terminado porque alguém supôs.

O `tools/probe.py` existe pra fechar essas lacunas com a máquina na frente: ele
conecta, despeja o JSON cru e diz exatamente o que precisa virar constante
aqui.
"""
from __future__ import annotations

import json
import ssl
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable

import paho.mqtt.client as mqtt

from . import log

LOG = log.get("printer")

# Fases que a máquina reporta, na grafia dela. `stoped` com um p só é a grafia
# REAL do firmware — não é erro de digitação, e corrigir aqui quebraria o
# reconhecimento.
KNOWN_PHASES = {
    "preheating",
    "auto_leveling",
    "vibrating",
    "flow_calibrating",
    "printing",
    "pausing",
    "paused",
    "resuming",
    "stopping",
    "stoped",
    "stopped",
    "finished",
    "failed",
    "idle",
    "free",
    "ready",
}

# Chaves procuradas no JSON, em qualquer profundidade.
PHASE_KEYS = ("state", "print_state", "printstate", "job_state", "status")
FILE_KEYS = ("filename", "file_name", "name", "print_name")
TASK_KEYS = ("taskid", "task_id")
CODE_KEYS = ("code", "err_code", "error_code")
# Códigos de sucesso do envelope do report (não são erro): 0 e 200 (estilo HTTP).
OK_CODES = frozenset({0, 200})
MESSAGE_KEYS = ("msg", "message", "err_msg")


@dataclass
class PrinterState:
    """O retrato mais recente da máquina, já normalizado."""

    phase: str | None = None
    filename: str | None = None
    task_id: str | None = None
    progress: float | None = None
    curr_layer: int | None = None
    total_layers: int | None = None
    remain_minutes: float | None = None
    print_time_seconds: float | None = None
    supplies_usage: float | None = None
    error_code: int | None = None
    error_message: str | None = None
    updated_at: float = field(default_factory=time.time)

    def as_report(self) -> dict[str, Any]:
        """O que o servidor espera em `agent:printer`."""
        return {
            "phase": self.phase,
            "filename": self.filename,
            "taskId": self.task_id,
            "errorCode": self.error_code,
            "errorMessage": self.error_message,
        }

    def as_telemetry(self) -> dict[str, Any]:
        """O que o servidor espera em `agent:telemetry`."""
        return {
            "progress": self.progress,
            "currLayer": self.curr_layer,
            "totalLayers": self.total_layers,
            "remainMinutes": self.remain_minutes,
            "printTimeSeconds": self.print_time_seconds,
            "suppliesUsage": self.supplies_usage,
        }

    def busy(self) -> bool:
        return self.phase is not None and self.phase not in {"idle", "free", "ready"}


def _new_client(client_id: str) -> mqtt.Client:
    """
    Cria o client funcionando tanto no paho 1.6 quanto no 2.x.

    O 2.0 mudou a assinatura dos callbacks e exige declarar a versão da API. O
    Pi pode ter qualquer um dos dois dependendo de quando o venv foi criado, e
    descobrir isso por exceção de `TypeError` em produção é péssimo.
    """
    try:
        return mqtt.Client(
            mqtt.CallbackAPIVersion.VERSION1,  # type: ignore[attr-defined]
            client_id=client_id,
            protocol=mqtt.MQTTv311,
        )
    except AttributeError:
        return mqtt.Client(client_id=client_id, protocol=mqtt.MQTTv311)


class PrinterLink:
    """
    Conexão com a impressora. Reconecta sozinha, pra sempre.

    A impressora some quando alguém desliga na tomada ou o roteador reinicia —
    isso é rotina, não exceção, e por isso não existe caminho de erro que
    encerre o processo. O agente fica tentando e avisa o servidor que a máquina
    está inalcançável; a fila espera, que é o comportamento certo.
    """

    def __init__(
        self,
        on_state: Callable[[PrinterState], None],
        on_raw: Callable[[str, dict[str, Any]], None] | None = None,
    ) -> None:
        self.state = PrinterState()
        self.connected = False
        self.host: str | None = None
        self.model_id: int = 20025
        self.device_id: str | None = None
        self.topic_root = "anycubic/anycubicCloud/v1"

        self._on_state = on_state
        self._on_raw = on_raw
        self._client: mqtt.Client | None = None
        self._lock = threading.Lock()
        self._tls: dict[str, Any] = {}
        self._auth: tuple[str | None, str | None] = (None, None)
        self._port = 9883

    # ------------------------------------------------------------------
    # LIGAÇÃO
    # ------------------------------------------------------------------

    def configure(
        self,
        host: str,
        *,
        model_id: int,
        device_id: str | None,
        port: int,
        topic_root: str,
        tls: bool,
        tls_insecure: bool,
        ca_file: str | None,
        certfile: str | None,
        keyfile: str | None,
        username: str | None,
        password: str | None,
    ) -> None:
        """
        (Re)configura e conecta. Chamado a cada `agent:welcome`.

        Se só o IP mudou, derruba e sobe de novo — é barato e não tem estado a
        preservar: o primeiro report da máquina reconstrói tudo.
        """
        with self._lock:
            same = (
                self.host == host
                and self.model_id == model_id
                and self._port == port
                and self.device_id == device_id
            )
            if same and self.connected:
                return

            self.host = host
            self.model_id = model_id
            self.device_id = device_id
            self.topic_root = topic_root.strip("/")
            self._port = port
            self._tls = {
                "enabled": tls,
                "insecure": tls_insecure,
                "ca_file": ca_file,
                "certfile": certfile,
                "keyfile": keyfile,
            }
            self._auth = (username, password)

        self._reconnect()

    def _reconnect(self) -> None:
        self.stop()
        if not self.host:
            return

        client = _new_client(f"bocas-agent-{uuid.uuid4().hex[:8]}")
        username, password = self._auth
        if username:
            client.username_pw_set(username, password or None)

        if self._tls.get("enabled"):
            try:
                client.tls_set(
                    ca_certs=self._tls.get("ca_file"),
                    certfile=self._tls.get("certfile"),
                    keyfile=self._tls.get("keyfile"),
                    cert_reqs=ssl.CERT_NONE if self._tls.get("insecure") else ssl.CERT_REQUIRED,
                    tls_version=ssl.PROTOCOL_TLS_CLIENT,
                )
                if self._tls.get("insecure"):
                    # O certificado é da própria impressora e nenhuma CA
                    # assinou. Estamos na mesma LAN que ela; a alternativa é não
                    # ter canal nenhum.
                    client.tls_insecure_set(True)
            except Exception as error:  # noqa: BLE001
                LOG.error("TLS não configurou (%s) — tentando sem", error)

        client.on_connect = self._on_connect
        client.on_message = self._on_message
        client.on_disconnect = self._on_disconnect
        # `reconnect_delay_set` + `loop_start` fazem a reconexão sozinhos: sem
        # isso, uma queda do roteador deixaria o agente mudo pra sempre.
        client.reconnect_delay_set(min_delay=2, max_delay=60)

        self._client = client
        LOG.info("conectando na impressora %s:%s", self.host, self._port)
        try:
            client.connect_async(self.host, self._port, keepalive=45)
            client.loop_start()
        except Exception as error:  # noqa: BLE001
            LOG.error("falha ao conectar em %s:%s — %s", self.host, self._port, error)

    def stop(self) -> None:
        client, self._client = self._client, None
        self.connected = False
        if not client:
            return
        try:
            client.loop_stop()
            client.disconnect()
        except Exception:  # noqa: BLE001
            pass

    # ------------------------------------------------------------------
    # CALLBACKS
    # ------------------------------------------------------------------

    def _on_connect(self, client: mqtt.Client, _userdata: Any, _flags: Any, rc: int, *_rest) -> None:
        if rc != 0:
            LOG.error("impressora recusou a conexão (rc=%s)", rc)
            return

        self.connected = True

        # Curinga de propósito: o `deviceId` (mainboard) muitas vezes não é
        # conhecido de antemão, e é justamente o que aparece no TÓPICO do
        # primeiro report. Assinar tudo e aprender o id do tópico evita ter que
        # configurar na mão um número que ninguém sabe onde achar.
        topic = f"{self.topic_root}/printer/#"
        client.subscribe(topic, qos=0)
        LOG.info("assinado %s", topic)

        self.request_status()

    def _on_disconnect(self, _client: mqtt.Client, _userdata: Any, rc: int, *_rest) -> None:
        self.connected = False
        LOG.warning("impressora desconectou (rc=%s) — o paho reconecta sozinho", rc)

    def _on_message(self, _client: mqtt.Client, _userdata: Any, message: mqtt.MQTTMessage) -> None:
        try:
            raw = message.payload.decode("utf-8", errors="replace")
            payload = json.loads(raw)
        except (ValueError, AttributeError):
            LOG.debug("payload não-JSON em %s", message.topic)
            return

        if not isinstance(payload, dict):
            return

        # O tópico é `.../printer/public/<modelId>/<deviceId>/<ação>/report`.
        parts = message.topic.split("/")
        if self.device_id is None and len(parts) >= 7:
            self.device_id = parts[6]
            LOG.info("descobri o deviceId da impressora: %s", self.device_id)

        if self._on_raw:
            try:
                self._on_raw(message.topic, payload)
            except Exception:  # noqa: BLE001
                LOG.exception("handler de payload cru falhou")

        if self._merge(payload):
            self._on_state(self.state)

    # ------------------------------------------------------------------
    # PARSER TOLERANTE
    # ------------------------------------------------------------------

    def _merge(self, payload: dict[str, Any]) -> bool:
        """
        Costura o report no retrato atual. Devolve se algo mudou.

        Merge e não substituição porque a máquina manda reports PARCIAIS: um
        pacote de temperatura não traz `progress`, e sobrescrever zeraria a
        barra da tela a cada dois segundos.
        """
        flat = _flatten(payload)
        changed = False

        phase = _first_phase(flat)
        if phase and phase != self.state.phase:
            self.state.phase = phase
            changed = True

        for keys, attr, caster in (
            (FILE_KEYS, "filename", _as_filename),
            (TASK_KEYS, "task_id", _as_text),
            (("progress",), "progress", _as_float),
            (("curr_layer", "current_layer"), "curr_layer", _as_int),
            (("total_layers", "total_layer"), "total_layers", _as_int),
            (("remain_time", "remaining_time"), "remain_minutes", _as_float),
            (("print_time", "printed_time"), "print_time_seconds", _as_float),
            (("supplies_usage", "filament_used"), "supplies_usage", _as_float),
        ):
            value = _first(flat, keys, caster)
            if value is not None and getattr(self.state, attr) != value:
                setattr(self.state, attr, value)
                changed = True

        code = _first(flat, CODE_KEYS, _as_int)
        # `code: 0` E `code: 200` são "deu certo" — o report da S1 traz `code:200`
        # no envelope (estilo HTTP) em TODO relatório normal. Só código fora do
        # conjunto de sucesso vira erro na tela do grupo (erros reais são de 5
        # dígitos: 10101 ocupada, 10107 filamento rompido).
        if code and code not in OK_CODES:
            if self.state.error_code != code:
                self.state.error_code = code
                self.state.error_message = _first(flat, MESSAGE_KEYS, _as_text)
                changed = True
        elif code in OK_CODES and self.state.error_code is not None:
            self.state.error_code = None
            self.state.error_message = None
            changed = True

        if changed:
            self.state.updated_at = time.time()
        return changed

    # ------------------------------------------------------------------
    # COMANDOS
    # ------------------------------------------------------------------

    def _publish(self, action: str, payload: dict[str, Any]) -> bool:
        client = self._client
        if not client or not self.connected or not self.device_id:
            LOG.warning("sem canal com a impressora: comando %s não saiu", action)
            return False

        topic = f"{self.topic_root}/web/printer/{self.model_id}/{self.device_id}/{action}"
        body = {
            "type": action,
            "timestamp": int(time.time() * 1000),
            "msgid": uuid.uuid4().hex,
            **payload,
        }
        LOG.info("→ %s %s", topic, json.dumps(body)[:200])
        result = client.publish(topic, json.dumps(body), qos=0)
        return result.rc == mqtt.MQTT_ERR_SUCCESS

    def request_status(self) -> bool:
        return self._publish("status", {"action": "query", "data": None})

    def start_print(self, filename: str) -> bool:
        """
        Manda imprimir um arquivo que JÁ ESTÁ na impressora.

        O upload é HTTP (ver `upload.py`); isto aqui só aperta o play. Separar
        os dois é o que permite subir o arquivo com o `print=true` do
        OctoPrint e usar este caminho só como plano B.
        """
        return self._publish(
            "print",
            {
                "action": "start",
                "data": {"taskid": "0", "filename": filename, "filetype": 1},
            },
        )

    def pause(self) -> bool:
        return self._publish("print", {"action": "pause", "data": {"taskid": self.state.task_id or "0"}})

    def resume(self) -> bool:
        return self._publish("print", {"action": "resume", "data": {"taskid": self.state.task_id or "0"}})

    def stop_print(self) -> bool:
        """Para a IMPRESSÃO. (`stop()` desliga o MQTT — nomes parecidos, vidas diferentes.)"""
        return self._publish("print", {"action": "stop", "data": {"taskid": self.state.task_id or "0"}})


# ----------------------------------------------------------------------
# AJUDANTES DO PARSER
# ----------------------------------------------------------------------


def _flatten(payload: Any, depth: int = 0) -> dict[str, Any]:
    """
    Achata o JSON inteiro num dicionário `chave -> valor`.

    Chave repetida em profundidades diferentes fica com a MAIS FUNDA, que é
    onde a Anycubic costuma pôr o valor específico (`data.progress` vale mais
    que um `progress` de envelope). O limite de profundidade é só pra um
    payload malformado não virar recursão infinita.
    """
    out: dict[str, Any] = {}
    if depth > 6:
        return out

    if isinstance(payload, dict):
        for key, value in payload.items():
            if isinstance(value, (dict, list)):
                out.update(_flatten(value, depth + 1))
            else:
                out[str(key).lower()] = value
    elif isinstance(payload, list):
        for item in payload[:20]:
            out.update(_flatten(item, depth + 1))

    return out


def _first(flat: dict[str, Any], keys: tuple[str, ...], caster) -> Any:
    for key in keys:
        if key in flat:
            value = caster(flat[key])
            if value is not None:
                return value
    return None


def _first_phase(flat: dict[str, Any]) -> str | None:
    """
    Acha a fase.

    Chave conhecida com valor conhecido ganha. Se nada bater, devolve o valor
    cru da primeira chave de fase — o servidor guarda verbatim e NÃO mexe no
    estado do job quando não entende, que é o comportamento seguro.
    """
    fallback: str | None = None
    for key in PHASE_KEYS:
        value = flat.get(key)
        if not isinstance(value, str):
            continue
        cleaned = value.strip().lower()
        if not cleaned:
            continue
        if cleaned in KNOWN_PHASES:
            return cleaned
        fallback = fallback or cleaned
    return fallback


def _as_text(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text[:200] or None


def _as_filename(value: Any) -> str | None:
    text = _as_text(value)
    if not text:
        return None
    # A máquina às vezes devolve caminho completo (`/useremain/x.gcode`).
    return text.rsplit("/", 1)[-1]


def _as_float(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if number == number else None  # NaN


def _as_int(value: Any) -> int | None:
    number = _as_float(value)
    return int(number) if number is not None else None
