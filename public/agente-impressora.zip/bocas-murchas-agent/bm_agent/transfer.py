"""
O ARQUIVO — baixar do servidor e empurrar pra impressora.

Duas transferências grandes num aparelho pequeno. Tudo aqui é em STREAM, e
isso não é preciosismo: o Pi Zero tem 512 MB de RAM e um G-code de placa cheia
passa de 80 MB. Ler o arquivo na memória pra depois mandar é o caminho mais
curto pro OOM killer derrubar o agente no meio de um upload — e aí a peça de
alguém fica em `dispatching` até o watchdog desistir.

O sha256 é conferido ENQUANTO baixa, não depois: não custa nada (o hash corre
junto com a escrita) e evita mandar 80 MB truncados pra impressora, que viraria
uma impressão estragada descoberta três horas depois.
"""
from __future__ import annotations

import hashlib
import shutil
import uuid
from pathlib import Path
from typing import Any, Callable

import requests

from . import log

LOG = log.get("transfer")

CHUNK = 64 * 1024

# O Pi baixa 80 MB num wifi 2,4 GHz: minutos, não segundos. O timeout que
# importa é o de CONEXÃO — se o servidor não responde, adianta desistir; se
# está mandando devagar, não adianta.
DOWNLOAD_TIMEOUT = (10, 120)
UPLOAD_TIMEOUT = (10, 900)


class TransferError(RuntimeError):
    """
    Falha que o servidor precisa saber (vira `agent:job-failed`).

    O `code` carrega o erro da impressora quando existe. O que importa de
    verdade é o 10101 ("tarefa ainda ativa"): o servidor trata isso como
    ESPERA, não como falha, e não gasta tentativa de despacho com ele.
    """

    def __init__(self, message: str, code: int | None = None) -> None:
        super().__init__(message)
        self.code = code


def download(
    url: str,
    dest: Path,
    *,
    expected_sha256: str | None = None,
    expected_bytes: int | None = None,
    on_progress: Callable[[int], None] | None = None,
) -> Path:
    """
    Baixa o G-code pro disco do Pi, conferindo o hash no caminho.

    O servidor manda comprimido quando a gente aceita (`Accept-Encoding`), e o
    `requests` descomprime sozinho — o hash bate com o do conteúdo real, que é
    o que a impressora vai receber.
    """
    dest.parent.mkdir(parents=True, exist_ok=True)
    partial = dest.with_suffix(dest.suffix + ".part")

    if expected_bytes:
        free = shutil.disk_usage(dest.parent).free
        # Dobro do arquivo: o `.part` e o definitivo convivem por um instante no
        # `rename`, e cartão SD cheio corrompe de um jeito que não avisa.
        if free < expected_bytes * 2:
            raise TransferError(
                f"sem espaço no cartão: precisa de ~{expected_bytes * 2 // 1_000_000} MB, "
                f"tem {free // 1_000_000} MB"
            )

    digest = hashlib.sha256()
    total = 0

    try:
        with requests.get(url, stream=True, timeout=DOWNLOAD_TIMEOUT) as response:
            if response.status_code != 200:
                raise TransferError(
                    f"o servidor respondeu {response.status_code} ao baixar o arquivo"
                )

            with partial.open("wb") as handle:
                for chunk in response.iter_content(chunk_size=CHUNK):
                    if not chunk:
                        continue
                    handle.write(chunk)
                    digest.update(chunk)
                    total += len(chunk)
                    if on_progress:
                        on_progress(total)
    except requests.RequestException as error:
        partial.unlink(missing_ok=True)
        raise TransferError(f"download falhou: {error}") from error

    got = digest.hexdigest()
    if expected_sha256 and got != expected_sha256:
        partial.unlink(missing_ok=True)
        raise TransferError(
            "o arquivo chegou diferente do que o servidor mandou "
            f"(sha256 {got[:12]}… ≠ {expected_sha256[:12]}…)"
        )

    partial.replace(dest)
    LOG.info("baixado %s (%.1f MB)", dest.name, total / 1_000_000)
    return dest


class _MultipartStream:
    """
    O corpo do upload, montado à mão e lido do disco em pedaços.

    Por que não `requests(files=...)`: o `requests` monta o multipart INTEIRO na
    memória antes de mandar. São 80 MB de G-code num aparelho com 512 MB de RAM
    — o OOM killer derrubaria o agente no meio do upload, e a peça de alguém
    ficaria presa até o watchdog do servidor desistir.

    Com `__len__` e `read()`, o `requests` trata isto como arquivo: calcula o
    `Content-Length` certo (nada de `Transfer-Encoding: chunked`, que o
    servidor HTTP da impressora pode não aceitar) e lê em blocos.
    """

    def __init__(self, path: Path, filename: str, fields: dict[str, str], boundary: str) -> None:
        self._path = path
        self._size = path.stat().st_size
        self._handle = None
        self._progress = 0

        head = []
        for key, value in fields.items():
            head.append(
                f"--{boundary}\r\n"
                f'Content-Disposition: form-data; name="{key}"\r\n\r\n'
                f"{value}\r\n"
            )
        head.append(
            f"--{boundary}\r\n"
            f'Content-Disposition: form-data; name="file"; filename="{filename}"\r\n'
            f"Content-Type: application/octet-stream\r\n\r\n"
        )

        self._head = "".join(head).encode("utf-8")
        self._tail = f"\r\n--{boundary}--\r\n".encode("utf-8")
        self._cursor = 0
        self.on_progress: Callable[[int, int], None] | None = None

    def __len__(self) -> int:
        return len(self._head) + self._size + len(self._tail)

    def read(self, size: int = -1) -> bytes:
        if size is None or size < 0:
            size = CHUNK

        # 1) cabeçalho
        if self._cursor < len(self._head):
            chunk = self._head[self._cursor : self._cursor + size]
            self._cursor += len(chunk)
            return chunk

        # 2) o arquivo
        file_start = len(self._head)
        file_end = file_start + self._size
        if self._cursor < file_end:
            if self._handle is None:
                self._handle = self._path.open("rb")
            chunk = self._handle.read(min(size, file_end - self._cursor))
            if chunk:
                self._cursor += len(chunk)
                self._progress += len(chunk)
                if self.on_progress:
                    self.on_progress(self._progress, self._size)
                return chunk
            # Arquivo encolheu no meio do upload (não deveria): fecha e segue
            # pro rodapé em vez de girar em falso.
            self._cursor = file_end

        # 3) rodapé
        tail_offset = self._cursor - file_end
        if tail_offset < len(self._tail):
            chunk = self._tail[tail_offset : tail_offset + size]
            self._cursor += len(chunk)
            return chunk

        self.close()
        return b""

    def close(self) -> None:
        if self._handle:
            self._handle.close()
            self._handle = None


def upload_to_printer(
    path: Path,
    *,
    host: str,
    port: int,
    api_key: str | None,
    filename: str,
    autostart: bool,
    on_progress: Callable[[int, int], None] | None = None,
) -> dict[str, Any]:
    """
    Manda o arquivo pra impressora pela API compatível com OctoPrint.

    A Kobra expõe essa camada na porta 80 — é por ela que o OrcaSlicer manda
    peça direto. `select`/`print` fazem a máquina já começar; quando o firmware
    ignora isso (acontece), quem aperta o play é o MQTT, logo depois. É por isso
    que as duas coisas são separadas: o caminho que funcionar ganha, sem
    ninguém ter que descobrir antes qual dos dois é.
    """
    if not host:
        raise TransferError("o servidor não sabe o IP da impressora (Admin › Impressora)")

    url = f"http://{host}:{port}/api/files/local"
    boundary = f"----bocasmurchas{uuid.uuid4().hex}"
    body = _MultipartStream(
        path,
        filename,
        {"select": "true", "print": "true" if autostart else "false"},
        boundary,
    )
    body.on_progress = on_progress

    headers = {"Content-Type": f"multipart/form-data; boundary={boundary}"}
    if api_key:
        headers["X-Api-Key"] = api_key

    LOG.info("subindo %s (%.1f MB) pra impressora em %s", filename, path.stat().st_size / 1e6, host)
    try:
        response = requests.post(url, headers=headers, data=body, timeout=UPLOAD_TIMEOUT)
    except requests.RequestException as error:
        raise TransferError(f"a impressora não aceitou o arquivo: {error}") from error
    finally:
        body.close()

    if response.status_code in (401, 403):
        raise TransferError("a impressora recusou a chave de API (Admin › Impressora)")
    if response.status_code == 409:
        # A camada OctoPrint responde 409 quando já tem tarefa rodando. É o
        # mesmo caso do 10101 do MQTT: espera, não falha.
        raise TransferError("a impressora ainda está com outra tarefa", code=10101)
    if response.status_code >= 400:
        raise TransferError(
            f"a impressora respondeu {response.status_code} no upload: {response.text[:200]}"
        )

    try:
        return response.json() if response.content else {}
    except ValueError:
        return {}


def job_command(action: str, *, host: str, port: int, api_key: str | None) -> bool:
    """
    Pausar/retomar/parar pela camada OctoPrint — plano B do MQTT.

    Existe porque comando que não chega é pior que comando que falha: se o MQTT
    estiver fora do ar e a peça precisar parar (filamento acabando, peça
    descolando), qualquer caminho serve.
    """
    if not host:
        return False

    payload = {"command": "pause", "action": action} if action in ("pause", "resume") else {"command": "cancel"}
    try:
        response = requests.post(
            f"http://{host}:{port}/api/job",
            headers={"X-Api-Key": api_key} if api_key else {},
            json=payload,
            timeout=(5, 20),
        )
        return response.status_code < 400
    except requests.RequestException as error:
        LOG.warning("comando %s pela API HTTP falhou: %s", action, error)
        return False


def reachable(host: str | None, port: int, api_key: str | None) -> bool:
    """A máquina responde na rede? É o que vai no heartbeat."""
    if not host:
        return False
    try:
        response = requests.get(
            f"http://{host}:{port}/api/version",
            headers={"X-Api-Key": api_key} if api_key else {},
            timeout=(3, 5),
        )
        return response.status_code < 500
    except requests.RequestException:
        return False
