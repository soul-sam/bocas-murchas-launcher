"""
Configuração do agente.

O que mora no Pi é só o MÍNIMO pra ele encontrar o servidor: a URL da API e o
token do aparelho. Tudo que é da impressora — IP, chave da API, modelo — vem
do servidor no `agent:welcome`, a cada conexão.

Isso é de propósito. O IP da impressora muda quando alguém reinicia o
roteador, e a alternativa seria abrir SSH no Pi toda vez. Com a configuração
vindo do banco, o admin troca o IP na aba da impressora no launcher e o agente
obedece no mesmo segundo.

Arquivo em INI e não TOML/YAML: `configparser` é stdlib em qualquer Python que
o Raspberry Pi OS já tenha (o `tomllib` só existe do 3.11 pra cima, e o Pi Zero
de alguém pode estar num Bullseye antigo), e não precisa de dependência
nenhuma pra ler.
"""
from __future__ import annotations

import configparser
import os
from dataclasses import dataclass
from pathlib import Path

DEFAULT_PATH = Path("/etc/bocas-agent/agent.conf")

# Onde o G-code espera entre baixar e subir pra impressora.
#
# No Windows `/var/lib/...` vira `C:\var\lib\...`, na raiz do disco, e criar
# pasta ali pede administrador — o agente morreria no primeiro job. Como ele
# roda no computador de quem tem a impressora, o padrão segue o sistema.
DEFAULT_SPOOL = (
    r"%LOCALAPPDATA%\bocas-agent\spool"
    if os.name == "nt"
    else "/var/lib/bocas-agent/spool"
)


@dataclass
class Config:
    # ---- servidor ----------------------------------------------------------
    api_url: str
    token: str

    # ---- disco -------------------------------------------------------------
    spool_dir: Path

    # ---- impressora (fallback; o servidor manda os valores de verdade) -----
    printer_host: str | None
    printer_api_key: str | None
    printer_model_id: int
    device_id: str | None

    # ---- protocolo ---------------------------------------------------------
    mqtt_port: int
    mqtt_tls: bool
    mqtt_tls_insecure: bool
    mqtt_ca_file: str | None
    mqtt_certfile: str | None
    mqtt_keyfile: str | None
    mqtt_username: str | None
    mqtt_password: str | None
    topic_root: str

    # ---- câmera ------------------------------------------------------------
    # URL do snapshot JPEG. Vazio = `http://<host>:8080/?action=snapshot`, que é
    # o mjpg-streamer que o Rinkhals sobe no lugar da câmera da Anycubic.
    camera_url: str | None

    # ---- comportamento -----------------------------------------------------
    http_port: int
    start_on_upload: bool
    start_grace_seconds: int
    telemetry_seconds: int
    verify_sha256: bool
    log_level: str
    dump_unknown: bool

    @property
    def spool(self) -> Path:
        self.spool_dir.mkdir(parents=True, exist_ok=True)
        return self.spool_dir


def load(path: str | os.PathLike[str] | None = None) -> Config:
    """
    Lê o arquivo e deixa o ambiente ganhar.

    As variáveis de ambiente existem pro `systemd` e pra rodar o agente na mão
    numa máquina de teste sem mexer no arquivo do Pi — é como se depura isso
    sem estragar a configuração boa.
    """
    target = Path(path or os.environ.get("BM_AGENT_CONFIG", DEFAULT_PATH))

    # `interpolation=None` porque o padrão do configparser trata `%` como
    # sintaxe: `%LOCALAPPDATA%\...` e qualquer senha ou chave com `%` derrubam
    # a leitura inteira com `InterpolationSyntaxError`. Aqui nenhum valor é
    # template, então não há o que interpolar.
    parser = configparser.ConfigParser(interpolation=None)
    if target.exists():
        parser.read(target, encoding="utf-8")

    def get(section: str, key: str, default: str | None = None) -> str | None:
        env = os.environ.get(f"BM_{section.upper()}_{key.upper()}")
        if env is not None and env != "":
            return env
        if parser.has_option(section, key):
            value = parser.get(section, key).strip()
            return value or default
        return default

    def flag(section: str, key: str, default: bool) -> bool:
        raw = get(section, key, "sim" if default else "não")
        return str(raw).strip().lower() in {"1", "true", "yes", "sim", "on"}

    def number(section: str, key: str, default: int) -> int:
        raw = get(section, key, str(default))
        try:
            return int(str(raw).strip())
        except ValueError:
            return default

    api_url = (get("server", "api_url") or "").rstrip("/")
    token = get("server", "token") or ""

    if not api_url or not token:
        raise SystemExit(
            f"Faltou configurar {target}: precisa de [server] api_url e token.\n"
            "O token sai em Admin › Impressora › Agentes, no launcher, e aparece UMA vez."
        )

    return Config(
        api_url=api_url,
        token=token,
        # `%LOCALAPPDATA%` e `~` são expandidos aqui porque o configparser não
        # expande nada — sem isso viraria uma pasta com esse nome literal.
        spool_dir=Path(
            os.path.expandvars(
                os.path.expanduser(get("agent", "spool_dir", DEFAULT_SPOOL) or "")
            )
        ),
        printer_host=get("printer", "host"),
        printer_api_key=get("printer", "api_key"),
        printer_model_id=number("printer", "model_id", 20025),
        device_id=get("printer", "device_id"),
        mqtt_port=number("printer", "mqtt_port", 9883),
        mqtt_tls=flag("printer", "mqtt_tls", True),
        # A impressora usa certificado dela mesma, que nenhuma CA assinou. Não é
        # descuido: o agente e a máquina estão na MESMA LAN, e a alternativa
        # seria não ter canal nenhum.
        mqtt_tls_insecure=flag("printer", "mqtt_tls_insecure", True),
        mqtt_ca_file=get("printer", "mqtt_ca_file"),
        mqtt_certfile=get("printer", "mqtt_certfile"),
        mqtt_keyfile=get("printer", "mqtt_keyfile"),
        mqtt_username=get("printer", "mqtt_username"),
        mqtt_password=get("printer", "mqtt_password"),
        topic_root=get("printer", "topic_root", "anycubic/anycubicCloud/v1") or "",
        camera_url=get("printer", "camera_url"),
        http_port=number("printer", "http_port", 80),
        start_on_upload=flag("printer", "start_on_upload", True),
        start_grace_seconds=number("printer", "start_grace_seconds", 25),
        telemetry_seconds=number("agent", "telemetry_seconds", 5),
        verify_sha256=flag("agent", "verify_sha256", True),
        log_level=(get("agent", "log_level", "INFO") or "INFO").upper(),
        dump_unknown=flag("agent", "dump_unknown", False),
    )
