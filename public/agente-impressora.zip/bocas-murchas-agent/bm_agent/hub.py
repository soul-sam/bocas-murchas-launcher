"""
O AGENTE — a ponte entre a API e a máquina.

Regra que vale pro arquivo inteiro: **o agente não decide nada sobre a fila.**
Ele lê a impressora, conta o que viu e faz o que mandam. De quem é a vez, o que
pode ser cobrado, quando a mesa está suja — tudo isso mora no servidor, e é de
propósito: assim sobrevive a um cartão SD corrompido, que é como Raspberry
morre.

Três linhas de execução, e a divisão importa:

  - o SOCKET (thread do python-socketio) recebe ordens e manda eventos;
  - a IMPRESSORA (thread do paho) entrega report o tempo todo;
  - o TRABALHO (thread própria, uma de cada vez) baixa e sobe arquivo.

O trabalho precisa de thread separada porque baixar 15 MB e subir 80 MB num Pi
Zero leva minutos. Feito dentro do handler do socket, o cliente pararia de
responder aos pings e o servidor declararia o agente offline no meio do
próprio despacho que ele está executando.
"""
from __future__ import annotations

import platform
import threading
import time
from pathlib import Path
from typing import Any
from urllib.parse import urljoin

import socketio

from . import log, transfer
from . import VERSION
from .config import Config
from .printer import PrinterLink, PrinterState

LOG = log.get("agente")

NS = "/print-agent"

#: A cada quanto tempo o servidor ouve "ainda estou trabalhando" durante uma
#: transferência. Tem que ser bem menor que o `dispatchAckTimeoutMs` (60 s) do
#: servidor — é isso que impede o despacho de ser cancelado no meio de um
#: upload legítimo de 80 MB num wifi lento.
STAGE_EVERY = 5.0


class Agent:
    def __init__(self, config: Config) -> None:
        self.config = config
        self.printer = PrinterLink(on_state=self._on_printer_state)

        self.sio = socketio.Client(
            reconnection=True,
            reconnection_delay=2,
            reconnection_delay_max=60,
            randomization_factor=0.5,
            logger=False,
            engineio_logger=False,
        )

        self._welcome: dict[str, Any] = {}
        self._job_lock = threading.Lock()
        self._job: dict[str, Any] | None = None
        self._stop = threading.Event()

        self._last_phase: str | None = None
        self._last_telemetry = 0.0
        self._last_stage = 0.0

        self._register()

    # ------------------------------------------------------------------
    # CICLO DE VIDA
    # ------------------------------------------------------------------

    def run(self) -> None:
        threading.Thread(target=self._heartbeat_loop, name="heartbeat", daemon=True).start()

        while not self._stop.is_set():
            try:
                LOG.info("conectando na API %s", self.config.api_url)
                self.sio.connect(
                    self.config.api_url,
                    namespaces=[NS],
                    auth={"token": self.config.token, "version": VERSION},
                    transports=["websocket", "polling"],
                    wait_timeout=20,
                )
                self.sio.wait()
            except Exception as error:  # noqa: BLE001
                # Nunca desiste: a VPS pode estar em deploy, o wifi pode ter
                # caído, o DNS doméstico pode estar ruim. Um agente que morre
                # por isso é um agente que alguém precisa ir reiniciar na mão.
                LOG.warning("sem API (%s) — tento de novo em 15 s", error)
                self._stop.wait(15)

    def shutdown(self) -> None:
        self._stop.set()
        self.printer.stop()
        try:
            self.sio.disconnect()
        except Exception:  # noqa: BLE001
            pass

    # ------------------------------------------------------------------
    # EVENTOS DO SERVIDOR
    # ------------------------------------------------------------------

    def _register(self) -> None:
        sio = self.sio

        @sio.event(namespace=NS)
        def connect() -> None:  # noqa: ANN202
            LOG.info("conectado na API")
            self._emit(
                "agent:hello",
                {
                    "version": VERSION,
                    "host": platform.node(),
                    "printer": self.printer.state.as_report(),
                },
            )

        @sio.event(namespace=NS)
        def connect_error(data: Any) -> None:  # noqa: ANN202
            # Token revogado cai aqui. É o único erro que vale gritar no log:
            # todo o resto o `reconnection` resolve sozinho.
            LOG.error("a API recusou a conexão: %s", data)

        @sio.event(namespace=NS)
        def disconnect() -> None:  # noqa: ANN202
            LOG.warning("caí da API — reconectando")

        @sio.on("agent:welcome", namespace=NS)
        def on_welcome(data: dict[str, Any]) -> None:  # noqa: ANN202
            self._apply_welcome(data or {})

        @sio.on("job:print", namespace=NS)
        def on_job(data: dict[str, Any]) -> None:  # noqa: ANN202
            self._accept_job(data or {})

        @sio.on("job:command", namespace=NS)
        def on_command(data: dict[str, Any]) -> None:  # noqa: ANN202
            self._run_command(str((data or {}).get("action") or ""))

        @sio.on("printer:sync", namespace=NS)
        def on_sync(_data: Any = None) -> None:  # noqa: ANN202
            LOG.info("o servidor pediu ressincronia")
            self.printer.request_status()
            self._emit("agent:printer", self.printer.state.as_report())

    def _apply_welcome(self, data: dict[str, Any]) -> None:
        """
        A configuração da impressora vem do servidor, sempre.

        O cartão SD do Pi guarda só a URL da API e o token; IP, chave e modelo
        chegam aqui. Assim o admin troca o IP no launcher quando o roteador
        reinicia e o agente obedece sem ninguém abrir SSH.
        """
        self._welcome = data
        host = data.get("host") or self.config.printer_host
        if not host:
            LOG.error("o servidor não sabe o IP da impressora — configura em Admin › Impressora")
            return

        LOG.info("impressora: %s (%s) em %s", data.get("name"), data.get("model"), host)
        self.printer.configure(
            str(host),
            model_id=int(data.get("modelId") or self.config.printer_model_id),
            device_id=self.config.device_id,
            port=self.config.mqtt_port,
            topic_root=self.config.topic_root,
            tls=self.config.mqtt_tls,
            tls_insecure=self.config.mqtt_tls_insecure,
            ca_file=self.config.mqtt_ca_file,
            certfile=self.config.mqtt_certfile,
            keyfile=self.config.mqtt_keyfile,
            username=self.config.mqtt_username,
            password=self.config.mqtt_password,
        )

    # ------------------------------------------------------------------
    # A MÁQUINA FALOU
    # ------------------------------------------------------------------

    def _on_printer_state(self, state: PrinterState) -> None:
        """Chamado na thread do MQTT, a cada report que mudou alguma coisa."""
        if state.phase != self._last_phase or state.error_code:
            self._last_phase = state.phase
            self._emit("agent:printer", state.as_report())

        now = time.time()
        if now - self._last_telemetry >= self.config.telemetry_seconds:
            self._last_telemetry = now
            payload = state.as_telemetry()
            payload["jobId"] = (self._job or {}).get("jobId")
            self._emit("agent:telemetry", payload)

    # ------------------------------------------------------------------
    # TRABALHO
    # ------------------------------------------------------------------

    def _accept_job(self, data: dict[str, Any]) -> None:
        job_id = str(data.get("jobId") or "")
        if not job_id:
            return

        with self._job_lock:
            if self._job:
                # Dois despachos ao mesmo tempo não deveriam existir (o servidor
                # tem mutex), mas se existirem, recusar é melhor que embaralhar
                # dois uploads no mesmo aparelho.
                LOG.warning("já estou com a peça %s — recusando %s", self._job.get("jobId"), job_id)
                self._emit(
                    "agent:job-failed",
                    {"jobId": job_id, "reason": "o agente ainda está com outra peça", "code": 10101},
                )
                return
            self._job = data

        threading.Thread(target=self._work, args=(data,), name="job", daemon=True).start()

    def _work(self, job: dict[str, Any]) -> None:
        job_id = str(job.get("jobId"))
        filename = str(job.get("filename") or f"{job_id}.gcode")
        spool = self.config.spool / filename

        try:
            self._stage(job_id, "downloading", 0, force=True)
            url = urljoin(self.config.api_url + "/", str(job.get("url") or "").lstrip("/"))
            size = int(job.get("sizeBytes") or 0)

            transfer.download(
                url,
                spool,
                expected_sha256=str(job.get("sha256")) if self.config.verify_sha256 else None,
                expected_bytes=size or None,
                on_progress=lambda done: self._stage(
                    job_id, "downloading", _percent(done, size)
                ),
            )

            self._stage(job_id, "uploading", 0, force=True)
            transfer.upload_to_printer(
                spool,
                host=self._printer_host(),
                port=self.config.http_port,
                api_key=self._welcome.get("apiKey") or self.config.printer_api_key,
                filename=filename,
                autostart=self.config.start_on_upload,
                on_progress=lambda done, total: self._stage(
                    job_id, "uploading", _percent(done, total)
                ),
            )

            # A máquina tem o arquivo. A partir daqui o job é dela, e o servidor
            # passa a contar o tempo pelo report — por isso o aviso sai ANTES da
            # espera pelo start.
            self._emit(
                "agent:job-accepted",
                {"jobId": job_id, "taskId": self.printer.state.task_id},
            )

            self._ensure_started(job_id, filename)

        except transfer.TransferError as error:
            LOG.error("peça %s falhou: %s", job_id, error)
            self._emit(
                "agent:job-failed",
                {"jobId": job_id, "reason": str(error), "code": error.code},
            )
        except Exception as error:  # noqa: BLE001
            LOG.exception("peça %s morreu num jeito inesperado", job_id)
            self._emit("agent:job-failed", {"jobId": job_id, "reason": str(error)[:180]})
        finally:
            # O arquivo já está na impressora; segurar cópia no cartão SD do Pi
            # é desperdiçar o pouco espaço que ele tem.
            spool.unlink(missing_ok=True)
            with self._job_lock:
                self._job = None

    def _ensure_started(self, job_id: str, filename: str) -> None:
        """
        Confere se a máquina realmente começou — e aperta o play se não.

        O `print=true` do upload funciona em parte dos firmwares e é ignorado em
        outros. Em vez de escolher um caminho e torcer, o agente espera um
        pouco, olha o que a máquina está fazendo, e usa o MQTT como plano B.
        """
        grace = max(5, self.config.start_grace_seconds)

        if self._wait_for_start(filename, grace):
            LOG.info("a impressora começou %s sozinha", filename)
            return

        LOG.info("a impressora não começou sozinha — mandando start por MQTT")
        self.printer.start_print(filename)

        if self._wait_for_start(filename, grace):
            LOG.info("start por MQTT funcionou")
            return

        # Não desiste em silêncio: o servidor precisa saber pra devolver a peça
        # pra fila em vez de deixar a fila parada esperando uma impressão que
        # nunca começou.
        self._emit(
            "agent:job-failed",
            {
                "jobId": job_id,
                "reason": "mandei o arquivo e a impressora não começou",
                "code": self.printer.state.error_code,
            },
        )

    def _wait_for_start(self, filename: str, seconds: int) -> bool:
        deadline = time.time() + seconds
        while time.time() < deadline:
            state = self.printer.state
            if state.busy():
                # Nome bate, ou a máquina não disse o nome e está claramente
                # trabalhando — nos dois casos, começou.
                if not state.filename or state.filename == filename:
                    return True
            self.printer.request_status()
            time.sleep(2)
        return False

    def _run_command(self, action: str) -> None:
        LOG.info("comando do servidor: %s", action)

        sent = False
        if action == "pause":
            sent = self.printer.pause()
        elif action == "resume":
            sent = self.printer.resume()
        elif action == "stop":
            sent = self.printer.stop_print()

        if not sent:
            # Plano B pela camada HTTP: comando que não chega é pior que comando
            # que falha — quem pediu `stop` está vendo a peça descolar.
            LOG.warning("MQTT não levou o comando %s — tentando pela API HTTP", action)
            transfer.job_command(
                action,
                host=self._printer_host(),
                port=self.config.http_port,
                api_key=self._welcome.get("apiKey") or self.config.printer_api_key,
            )

        self.printer.request_status()

    # ------------------------------------------------------------------
    # SINAIS DE VIDA
    # ------------------------------------------------------------------

    def _heartbeat_loop(self) -> None:
        while not self._stop.is_set():
            interval = max(3, int(self._welcome.get("heartbeatMs", 10_000)) // 1000)
            if self.sio.connected:
                self._emit(
                    "agent:heartbeat",
                    {
                        "printerReachable": self.printer.connected
                        or transfer.reachable(
                            self._printer_host(),
                            self.config.http_port,
                            self._welcome.get("apiKey") or self.config.printer_api_key,
                        ),
                        "busy": self._job is not None,
                    },
                )
            self._stop.wait(interval)

    def _stage(self, job_id: str, stage: str, percent: int, force: bool = False) -> None:
        """
        "Ainda estou trabalhando."

        Sem isto, um upload honesto de 80 MB num wifi ruim estouraria o prazo de
        confirmação do servidor e a peça voltaria pra fila — pra ser mandada de
        novo, e estourar de novo, até virar falha. O servidor usa este evento
        pra remarcar o prazo, e de quebra a tela mostra "mandando arquivo (43%)".
        """
        now = time.time()
        if not force and now - self._last_stage < STAGE_EVERY:
            return
        self._last_stage = now
        self._emit("agent:job-stage", {"jobId": job_id, "stage": stage, "percent": percent})

    def _emit(self, event: str, payload: dict[str, Any]) -> None:
        if not self.sio.connected:
            return
        try:
            self.sio.emit(event, payload, namespace=NS)
        except Exception as error:  # noqa: BLE001
            LOG.debug("falha ao emitir %s: %s", event, error)

    def _printer_host(self) -> str:
        return str(self._welcome.get("host") or self.config.printer_host or "")


def _percent(done: int, total: int) -> int:
    if not total:
        return 0
    return max(0, min(100, int(done * 100 / total)))
