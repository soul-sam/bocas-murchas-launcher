"""
Entrada do agente: `python -m bm_agent`.

Praticamente não tem lógica aqui de propósito — o que este arquivo faz é ler a
configuração, ligar o log e entregar o processo pro `Agent`. Quem reinicia
quando algo dá errado é o `systemd` (`Restart=always`), não um `try` gigante em
volta de tudo: processo que insiste em viver depois de um erro que não entende
é processo que mente sobre estar funcionando.
"""
from __future__ import annotations

import argparse
import signal
import sys
from types import FrameType

from . import VERSION, log
from .config import load
from .hub import Agent


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="bm_agent",
        description="Agente da impressora 3D do Bocas Murchas.",
    )
    parser.add_argument("-c", "--config", help="caminho do agent.conf")
    parser.add_argument("--version", action="version", version=f"bocas-agent {VERSION}")
    args = parser.parse_args(argv)

    config = load(args.config)
    log.setup(config.log_level)
    logger = log.get("main")

    logger.info("bocas-agent %s — API em %s", VERSION, config.api_url)
    logger.info("spool em %s", config.spool)

    agent = Agent(config)

    def bye(signum: int, _frame: FrameType | None) -> None:
        logger.info("recebi sinal %s — encerrando", signum)
        agent.shutdown()
        sys.exit(0)

    signal.signal(signal.SIGTERM, bye)
    signal.signal(signal.SIGINT, bye)

    agent.run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
