#!/usr/bin/env python3
"""
A SONDA — o spike que fecha o que não dá pra saber sem a máquina na frente.

O protocolo local da Kobra não é documentado por ninguém: o `bm_agent/printer.py`
foi escrito tolerante justamente porque parte do formato é conhecimento de
comunidade, não especificação. Este script é como se confirma o resto em dez
minutos, com a impressora ligada:

    python3 tools/probe.py --host 192.168.18.50

Ele faz, nesta ordem:

  1. procura impressoras na LAN (broadcast UDP);
  2. bate na camada HTTP compatível com OctoPrint (é ela que recebe o upload);
  3. conecta no MQTT e DESPEJA TODO PAYLOAD CRU que chegar, com o tópico.

O passo 3 é o que importa. Com dois minutos de saída dele dá pra conferir, sem
adivinhar: o `deviceId` real, como a máquina chama cada fase, e em que chave
vêm `progress`, `curr_layer`, `remain_time` e `supplies_usage`. Se algo não
bater com `bm_agent/printer.py`, o conserto é acrescentar a chave nas listas do
topo daquele arquivo — não reescrever nada.

Nada aqui escreve na impressora (não manda imprimir, não move eixo). É só
leitura.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import requests  # noqa: E402

from bm_agent import discovery, log  # noqa: E402
from bm_agent.printer import PrinterLink, PrinterState  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description="Sonda do protocolo da impressora.")
    parser.add_argument("--host", help="IP da impressora (sem isto, procura na LAN)")
    parser.add_argument("--model-id", type=int, default=20025, help="20025 = Kobra S1")
    parser.add_argument("--device-id", help="id da placa, se você já souber")
    parser.add_argument("--mqtt-port", type=int, default=9883)
    parser.add_argument("--http-port", type=int, default=80)
    parser.add_argument("--api-key", help="chave da API compatível com OctoPrint")
    parser.add_argument("--no-tls", action="store_true")
    parser.add_argument("--seconds", type=int, default=120, help="quanto tempo fica ouvindo")
    parser.add_argument("--out", help="salva os payloads crus neste arquivo (JSONL)")
    args = parser.parse_args()

    log.setup("INFO")

    host = args.host
    if not host:
        print("\n== procurando impressora na rede ==")
        found = discovery.find_printers()
        if not found:
            print("nada respondeu ao broadcast. Passa --host com o IP do painel da impressora.")
            return 1
        for item in found:
            print(" ", json.dumps(item, ensure_ascii=False)[:300])
        host = found[0]["ip"]
        print(f"usando {host}")

    print("\n== camada HTTP (é por ela que o arquivo sobe) ==")
    probe_http(host, args.http_port, args.api_key)

    print("\n== MQTT ==")
    out = open(args.out, "a", encoding="utf-8") if args.out else None
    seen_topics: set[str] = set()
    seen_keys: set[str] = set()

    def on_raw(topic: str, payload: dict) -> None:
        if topic not in seen_topics:
            seen_topics.add(topic)
            print(f"\n--- tópico novo: {topic}")
        line = json.dumps(payload, ensure_ascii=False)
        print(f"  {line[:600]}")
        for key in _keys(payload):
            if key not in seen_keys:
                seen_keys.add(key)
        if out:
            out.write(json.dumps({"topic": topic, "payload": payload}, ensure_ascii=False) + "\n")
            out.flush()

    def on_state(state: PrinterState) -> None:
        print(
            f"  → fase={state.phase} arquivo={state.filename} tarefa={state.task_id} "
            f"progresso={state.progress} camada={state.curr_layer}/{state.total_layers} "
            f"faltam={state.remain_minutes}min erro={state.error_code}"
        )

    link = PrinterLink(on_state=on_state, on_raw=on_raw)
    link.configure(
        host,
        model_id=args.model_id,
        device_id=args.device_id,
        port=args.mqtt_port,
        topic_root="anycubic/anycubicCloud/v1",
        tls=not args.no_tls,
        tls_insecure=True,
        ca_file=None,
        certfile=None,
        keyfile=None,
        username=None,
        password=None,
    )

    deadline = time.time() + args.seconds
    try:
        while time.time() < deadline:
            time.sleep(2)
            if not link.connected:
                continue
            link.request_status()
    except KeyboardInterrupt:
        pass
    finally:
        link.stop()
        if out:
            out.close()

    print("\n== resumo ==")
    print(f"deviceId descoberto: {link.device_id}")
    print(f"tópicos vistos: {len(seen_topics)}")
    for topic in sorted(seen_topics):
        print("  ", topic)
    print("\nchaves vistas nos payloads (é aqui que se confere o parser):")
    print("  " + ", ".join(sorted(seen_keys)) or "  (nenhuma)")

    if not link.connected:
        print(
            "\nNão conectou no MQTT. Coisas pra tentar, nesta ordem:\n"
            "  --no-tls                       (algumas versões falam sem TLS)\n"
            "  --mqtt-port 1883 / 9883 / 8883\n"
            "  conferir se a impressora está em modo LAN no painel\n"
            "Se a camada HTTP acima respondeu, o upload já funciona — falta só o controle."
        )
    return 0


def probe_http(host: str, port: int, api_key: str | None) -> None:
    headers = {"X-Api-Key": api_key} if api_key else {}
    for path in ("/api/version", "/api/printer", "/api/job", "/api/files"):
        url = f"http://{host}:{port}{path}"
        try:
            response = requests.get(url, headers=headers, timeout=(3, 8))
            body = response.text[:300].replace("\n", " ")
            print(f"  {response.status_code} {path} → {body}")
        except requests.RequestException as error:
            print(f"  ERRO {path} → {error}")


def _keys(payload, prefix: str = "") -> list[str]:
    out: list[str] = []
    if isinstance(payload, dict):
        for key, value in payload.items():
            path = f"{prefix}.{key}" if prefix else str(key)
            if isinstance(value, (dict, list)):
                out.extend(_keys(value, path))
            else:
                out.append(f"{path}={_short(value)}")
    elif isinstance(payload, list) and payload:
        out.extend(_keys(payload[0], f"{prefix}[]"))
    return out


def _short(value) -> str:
    text = str(value)
    return text[:24] + "…" if len(text) > 24 else text


if __name__ == "__main__":
    raise SystemExit(main())
