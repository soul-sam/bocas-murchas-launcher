#!/usr/bin/env bash
#
# Instala o agente no Raspberry Pi. Roda NO PI, como root:
#
#     sudo ./install.sh
#
# É idempotente: rodar de novo atualiza o código e reinicia o serviço sem
# perder a configuração. É assim que se publica versão nova.
set -euo pipefail

APP_DIR=/opt/bocas-agent
CONF_DIR=/etc/bocas-agent
DATA_DIR=/var/lib/bocas-agent
SERVICE=bocas-agent
USER_NAME=bocas

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ $EUID -ne 0 ]]; then
  echo "roda como root: sudo ./install.sh" >&2
  exit 1
fi

echo "==> pacotes do sistema"
# python3-venv vem separado no Raspberry Pi OS e a falta dele é o erro mais
# comum desta instalação ("ensurepip is not available").
apt-get update -qq
apt-get install -y --no-install-recommends python3 python3-venv python3-pip ca-certificates

echo "==> usuário $USER_NAME"
if ! id "$USER_NAME" >/dev/null 2>&1; then
  # Sem shell e sem home: este usuário existe pra rodar um processo, não pra
  # alguém entrar com ele.
  useradd --system --no-create-home --shell /usr/sbin/nologin "$USER_NAME"
fi

echo "==> diretórios"
install -d -o "$USER_NAME" -g "$USER_NAME" "$APP_DIR" "$DATA_DIR" "$DATA_DIR/spool"
install -d "$CONF_DIR"

echo "==> código"
rm -rf "$APP_DIR/bm_agent" "$APP_DIR/tools"
cp -r "$SOURCE_DIR/bm_agent" "$APP_DIR/"
cp -r "$SOURCE_DIR/tools" "$APP_DIR/"
cp "$SOURCE_DIR/requirements.txt" "$APP_DIR/"
chown -R "$USER_NAME:$USER_NAME" "$APP_DIR"

echo "==> venv e dependências (só wheel pura — nada compila aqui)"
if [[ ! -x "$APP_DIR/venv/bin/python" ]]; then
  python3 -m venv "$APP_DIR/venv"
fi
"$APP_DIR/venv/bin/pip" install --quiet --upgrade pip
"$APP_DIR/venv/bin/pip" install --quiet -r "$APP_DIR/requirements.txt"
chown -R "$USER_NAME:$USER_NAME" "$APP_DIR/venv"

echo "==> configuração"
if [[ ! -f "$CONF_DIR/agent.conf" ]]; then
  cp "$SOURCE_DIR/agent.conf.example" "$CONF_DIR/agent.conf"
  echo "    criado $CONF_DIR/agent.conf — PRECISA colar o token lá"
else
  echo "    $CONF_DIR/agent.conf já existe, mantido"
fi
# O token da impressora inteira mora aqui: ninguém além do root e do serviço lê.
chown root:"$USER_NAME" "$CONF_DIR/agent.conf"
chmod 640 "$CONF_DIR/agent.conf"

echo "==> wifi sem economia de energia"
# O wifi do Pi Zero dorme por padrão e derruba conexões ociosas. O socket do
# agente fica aberto horas sem tráfego durante uma impressão — é exatamente o
# caso que o power save mata.
cat > /etc/systemd/system/bocas-agent-wifi.service <<'UNIT'
[Unit]
Description=Desliga o power save do wifi (o socket do agente fica ocioso por horas)
After=network.target

[Service]
Type=oneshot
ExecStart=/bin/sh -c 'iw dev wlan0 set power_save off || true'
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
UNIT
systemctl enable --now bocas-agent-wifi.service >/dev/null 2>&1 || true

echo "==> serviço"
cp "$SOURCE_DIR/bocas-agent.service" /etc/systemd/system/$SERVICE.service
systemctl daemon-reload
systemctl enable $SERVICE >/dev/null

if grep -q "COLE-O-TOKEN-AQUI" "$CONF_DIR/agent.conf"; then
  echo
  echo "Falta o token. No launcher: Admin › Impressora › Agentes › Criar token."
  echo "Cola em $CONF_DIR/agent.conf e depois:"
  echo "    sudo systemctl start $SERVICE"
  echo "    journalctl -u $SERVICE -f"
else
  systemctl restart $SERVICE
  sleep 2
  systemctl --no-pager --lines=15 status $SERVICE || true
  echo
  echo "Pronto. Pra acompanhar:  journalctl -u $SERVICE -f"
fi
